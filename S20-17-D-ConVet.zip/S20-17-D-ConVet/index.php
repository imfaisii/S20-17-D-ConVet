<?php
$host = "localhost";
$dbUsername = "root";
$dbPassword = "YES";
$dbname = "fyp";
$answer;
@$a=$_POST['serviceName'];  
@$b=$_POST['Date']; 
$id2=$_GET['id1'];
//create connection
$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
if (mysqli_connect_error()) {
 die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
} else {  
if(@$_POST['submit'])  
{  
$s="insert into services(serviceName,Date,startedBy) values('$a','$b','$id2')";  
mysqli_query($conn, $s);
header("location:pages/orderdone.php?$id2");
} 
} 
  ?> 
<!DOCTYPE html>
<html lang="en">

<head>
  <title>ConVet &mdash; Connecting People</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  
  <link href="https://fonts.googleapis.com/css?family=Muli:300,400,700,900" rel="stylesheet">
  <link rel="stylesheet" href="fonts/icomoon/style.css">

  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/jquery-ui.css">
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">

  <link rel="stylesheet" href="css/jquery.fancybox.min.css">

  <link rel="stylesheet" href="css/bootstrap-datepicker.css">

  <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

  <link rel="stylesheet" href="css/aos.css">
  <link href="css/jquery.mb.YTPlayer.min.css" media="all" rel="stylesheet" type="text/css">

  <link rel="stylesheet" href="css/style.css">



</head>
<script>
  var $form = $('#payment-form');
$form.on('submit', payWithStripe);

/* If you're using Stripe for payments */
function payWithStripe(e) {
e.preventDefault();

/* Visual feedback */
$form.find('[type=submit]').html('Validating <i class="fa fa-spinner fa-pulse"></i>');

var PublishableKey = 'pk_test_b1qXXwATmiaA1VDJ1mOVVO1p'; // Replace with your API publishable key
Stripe.setPublishableKey(PublishableKey);

/* Create token */
var expiry = $form.find('[name=cardExpiry]').payment('cardExpiryVal');
var ccData = {
   number: $form.find('[name=cardNumber]').val().replace(/\s/g,''),
   cvc: $form.find('[name=cardCVC]').val(),
   exp_month: expiry.month, 
   exp_year: expiry.year
};

Stripe.card.createToken(ccData, function stripeResponseHandler(status, response) {
   if (response.error) {
       /* Visual feedback */
       $form.find('[type=submit]').html('Try again');
       /* Show Stripe errors on the form */
       $form.find('.payment-errors').text(response.error.message);
       $form.find('.payment-errors').closest('.row').show();
   } else {
       /* Visual feedback */
       $form.find('[type=submit]').html('Processing <i class="fa fa-spinner fa-pulse"></i>');
       /* Hide Stripe errors on the form */
       $form.find('.payment-errors').closest('.row').hide();
       $form.find('.payment-errors').text("");
       // response contains id and card, which contains additional card details            
       console.log(response.id);
       console.log(response.card);
       var token = response.id;
       // AJAX - you would send 'token' to your server here.
       $.post('/account/stripe_card_token', {
               token: token
           })
           // Assign handlers immediately after making the request,
           .done(function(data, textStatus, jqXHR) {
               $form.find('[type=submit]').html('Payment successful <i class="fa fa-check"></i>').prop('disabled', true);
           })
           .fail(function(jqXHR, textStatus, errorThrown) {
               $form.find('[type=submit]').html('There was a problem').removeClass('success').addClass('error');
               /* Show Stripe errors on the form */
               $form.find('.payment-errors').text('Try refreshing the page and trying again.');
               $form.find('.payment-errors').closest('.row').show();
           });
   }
});
}
/* Fancy restrictive input formatting via jQuery.payment library*/
$('input[name=cardNumber]').payment('formatCardNumber');
$('input[name=cardCVC]').payment('formatCardCVC');
$('input[name=cardExpiry').payment('formatCardExpiry');

/* Form validation using Stripe client-side validation helpers */
jQuery.validator.addMethod("cardNumber", function(value, element) {
return this.optional(element) || Stripe.card.validateCardNumber(value);
}, "Please specify a valid credit card number.");

jQuery.validator.addMethod("cardExpiry", function(value, element) {    
/* Parsing month/year uses jQuery.payment library */
value = $.payment.cardExpiryVal(value);
return this.optional(element) || Stripe.card.validateExpiry(value.month, value.year);
}, "Invalid expiration date.");

jQuery.validator.addMethod("cardCVC", function(value, element) {
return this.optional(element) || Stripe.card.validateCVC(value);
}, "Invalid CVC.");

validator = $form.validate({
rules: {
   cardNumber: {
       required: true,
       cardNumber: true            
   },
   cardExpiry: {
       required: true,
       cardExpiry: true
   },
   cardCVC: {
       required: true,
       cardCVC: true
   }
},
highlight: function(element) {
   $(element).closest('.form-control').removeClass('success').addClass('error');
},
unhighlight: function(element) {
   $(element).closest('.form-control').removeClass('error').addClass('success');
},
errorPlacement: function(error, element) {
   $(element).closest('.form-group').append(error);
}
});

paymentFormReady = function() {
if ($form.find('[name=cardNumber]').hasClass("success") &&
   $form.find('[name=cardExpiry]').hasClass("success") &&
   $form.find('[name=cardCVC]').val().length > 1) {
   return true;
} else {
   return false;
}
}

$form.find('[type=submit]').prop('disabled', true);
var readyInterval = setInterval(function() {
if (paymentFormReady()) {
   $form.find('[type=submit]').prop('disabled', false);
   clearInterval(readyInterval);
}
}, 250);
</script>
<style>
  input[type=radio] {
    width: 20px;
    height: 20px;
}
</style>
<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">

  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>


    <header class="site-navbar py-4 js-sticky-header site-navbar-target" role="banner">

      <div class="container-fluid">
        <div class="d-flex align-items-center">
          <div class="site-logo"><a href="index.html">ConVet<span>.</span> </a></div>
          <div class="ml-auto">
            <nav class="site-navigation position-relative text-right" role="navigation">
              <ul class="site-menu main-menu js-clone-nav mr-auto d-none d-lg-block">
                <li><a href="pages/home.php" class="nav-link">Home</a></li>
                <li><a href="#services-section" class="nav-link">Services</a></li>
                <li><a href="#schedule-section" class="nav-link">Schedule</a></li>
                <li><a href="#contact-section" class="nav-link">Payment</a></li>
              </ul>
            </nav>
            <a href="#" class="d-inline-block d-lg-none site-menu-toggle js-menu-toggle float-right"><span class="icon-menu h3"></span></a>
          </div>

        </div>
      </div>

    </header>


    <div class="intro-section" id="home-section" style="background-color: #ccc;">

      <div class="container">

        <div class="row align-items-center">
          <div class="col-lg-12 mx-auto text-center" data-aos="fade-up">
            <h1 class="mb-3">ConVet</h1>
            <p class="lead mx-auto desc mb-5">Services block where you can select the desired service from the services below, Schedule the meeting
              and Go through the Payment process. So, what are you waiting let's,
            </p>
            <p class="text-center">
              <a href="#services-section" class="btn btn-outline-white py-3 px-5">Get Started</a>
            </p>
          </div>
        </div>

      </div>
    </div>


    <div class="site-section" id="services-section">
      <div class="container">
        <div class="row justify-content-center text-center mb-5" data-aos="fade-up">
          <div class="col-md-8  section-heading">
            <h2 class="heading mb-3">Services</h2>
            
          </div>
        </div>

        <div class="row">
          <div class="col-lg-4 mb-4 col-md-6" data-aos="fade-up" data-aos-delay="">
            <div class="ftco-feature-1">
              <span><img class="img-fluid" src="images/motivational.jfif" height="400px" width="400px" alt=""></span>
              <div class="ftco-feature-1-text">
                <h2>Motivational Talks</h2>
                <p>If you are fond of dilivering your knoowledge for someone's better future.</p>
              </div>
            </div>
          </div>
          <div class="col-lg-4 mb-4 col-md-6" data-aos="fade-up" data-aos-delay="100">
            <div class="ftco-feature-1">
              <span><img class="img-fluid" src="images/plantation.jfif" height="400px" width="400px" alt=""></span>
              <div class="ftco-feature-1-text">
                <h2>Plantation Drive</h2>
                <p>Work for a green world!</p>
              </div>
            </div>
          </div>
          <div class="col-lg-4 mb-4 col-md-6" data-aos="fade-up" data-aos-delay="200">
            <div class="ftco-feature-1">
              <span><img class="img-fluid" src="images/picnic.jfif" alt=""></span>
              <div class="ftco-feature-1-text">
                <h2>Picnic</h2>
                <p>Get your mind a refreshed , Stay Healthy</p>
              </div>
            </div>
          </div>

          <div class="col-lg-4 mb-4 col-md-6" data-aos="fade-up" data-aos-delay="">
            <div class="ftco-feature-1">
              <span><img class="img-fluid" src="images/public.jpg" height="400px" width="400px" alt=""></span>
              <div class="ftco-feature-1-text">
                <h2>Public Talks</h2>
                <p>YOu can be a part a public rally , fight for rights and someones voice</p>
              </div>
            </div>
          </div>

          <div class="col-lg-4 mb-4 col-md-6" data-aos="fade-up" data-aos-delay="100">
            <div class="ftco-feature-1">
              <span><img class="img-fluid" src="images/lecturar.jpg" height="400px" width="400px" alt=""></span>
              <div class="ftco-feature-1-text">
                <h2>Lecturer <i class="fa fa-italic" aria-hidden="true">(Can be payed or not)</i></h2>
                <p>As a substitution deliver a lecture</p>
              </div>
            </div>
          </div>

          <div class="col-lg-4 mb-4 col-md-6" data-aos="fade-up" data-aos-delay="200">
            <div class="ftco-feature-1">
              <span><img class="img-fluid" src="images/office.jpg" height="400px" width="400px" alt=""></span>
              <div class="ftco-feature-1-text">
                <h2>Office Job <i class="fa fa-italic" aria-hidden="true">(Can be payed or not)</i></h2>
                <p>Do job until the one with the job comes back</p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
    
    
    <div class="site-section" id="schedule-section" style="padding-bottom:0%;">
      <div class="container">
        <div class="row justify-content-center text-center mb-5">
          <div class="col-md-8  section-heading">
            <h2 class="heading mb-3">Schedule</h2>
          </div>
        </div>

        
        <div class="row">
          <div class="col-12">
            <ul class="nav days d-flex" role="tablist">
              <li class="nav-item">
                <a class="nav-link active" id="sunday-tab" data-toggle="tab" href="#nav-sunday" role="tab" aria-controls="sunday"
                  aria-selected="true">S</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="monday-tab" data-toggle="tab" href="#nav-monday" role="tab" aria-controls="monday"
                  aria-selected="false">M</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="tuesday-tab" data-toggle="tab" href="#nav-tuesday" role="tab" aria-controls="tuesday"
                  aria-selected="false">T</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="wednesday-tab" data-toggle="tab" href="#nav-wednesday" role="tab" aria-controls="wednesday"
                  aria-selected="false">W</a>
              </li>

              <li class="nav-item">
                <a class="nav-link" id="thursday-tab" data-toggle="tab" href="#nav-thursday" role="tab" aria-controls="thursday"
                  aria-selected="false">T</a>
              </li><li class="nav-item">
                <a class="nav-link" id="friday-tab" data-toggle="tab" href="#nav-friday" role="tab" aria-controls="friday"
                  aria-selected="false">F</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="saturday-tab" data-toggle="tab" href="#nav-saturday" role="tab" aria-controls="saturday"
                  aria-selected="false">S</a>
              </li>
            </ul>
          </div>
        </div>

        <div class="tab-content">
          <div class="tab-pane fade show active" id="nav-sunday" role="tabpanel" aria-labelledby="nav-sunday-tab">
            <div class="row">
              <div class="col-lg-1"></div>
              <div class="col-lg-6">
                <h2><strong>Check a service from below and then set time and Date</strong></h2>
                <form method="post">
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="serviceName" id="exampleRadios1" value="Motivational Talk">
                  <label class="form-check-label" for="exampleRadios1">
                    <h3 style="padding-left: 2%;">Motivational Talks --</h3>
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="serviceName" id="exampleRadios2" value="Plantatoin Drive">
                  <label class="form-check-label" for="exampleRadios1">
                    <h3 style="padding-left: 2%;">Plantation Drive --</h3>
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="serviceName" id="exampleRadios3" value="Picnic">
                  <label class="form-check-label" for="exampleRadios1">
                    <h3 style="padding-left: 2%;">Picnic --</h3>
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="serviceName" id="exampleRadios4" value="Public Talk">
                  <label class="form-check-label" for="exampleRadios1">
                    <h3 style="padding-left: 2%;">Public Talks--</h3>
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="serviceName" id="exampleRadios5" value="Lecturer">
                  <label class="form-check-label" for="exampleRadios1">
                    <h3 style="padding-left: 2%;">Lecturer (Substitute)--</h3>
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="serviceName" id="exampleRadios6" value="Employee">
                  <label class="form-check-label" for="exampleRadios1">
                    <h3 style="padding-left: 2%;">Employee (Substitute)</h3>
                  </label>
                </div>
                <h2><strong>Date and Time Control</strong></h2>
                  <label for="birthdaytime">Service (date and time):</label>
                  <input type="datetime-local" id="birthdaytime" name="Date">
                  <br><br>
                  <a href=""><input class="btn btn-primary" type="submit" name="submit" value="Apply for this service"></a>
              </form>
            </div>
              <div class="col-lg-4">
              </div>
          </div>
          <div class="tab-pane fade" id="nav-monday" role="tabpanel" aria-labelledby="nav-monday-tab">
          </div>
          <div class="tab-pane fade" id="nav-tuesday" role="tabpanel" aria-labelledby="nav-tuesday-tab">
            
          </div>
          <div class="tab-pane fade" id="nav-wednesday" role="tabpanel" aria-labelledby="nav-wednesday-tab">
            
          </div>

          <div class="tab-pane fade" id="nav-thursday" role="tabpanel" aria-labelledby="nav-thursday-tab">
            
          </div>
          <div class="tab-pane fade" id="nav-friday" role="tabpanel" aria-labelledby="nav-friday-tab">
            
          </div>
          <div class="tab-pane fade" id="nav-saturday" role="tabpanel" aria-labelledby="nav-saturday-tab">
            
          </div>
        </div>
        
      </div>
      <br>
    </div>
    <div class="site-section bg-dark contact-wrap" id="contact-section">
      <div class="container">
        
        <div class="row justify-content-center text-center mb-5">
          <div class="col-md-8  section-heading">
            <span class="subheading">Get In Touch</span>
            <h2 class="heading mb-3">Payment Details</h2>
          </div>
        </div>
        <div class="row">
<div class="col-lg-3"></div>
<div class="col-lg-2">
<button class="btn btn-outline-white py-3 px-5" onclick="myFunction()">Are you paying ?</button>
</div>
<div class="col-lg-2"></div>
<div class="col-lg-4">
<button class="btn btn-outline-white py-3 px-5" onclick="myFunction1()">Are you getting paid ?</button>
</div>

<script>
function myFunction() {
  var x = document.getElementById("myDIV");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
function myFunction1() {
  var x = document.getElementById("myDIV1");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
</script>
<div id="myDIV" style="display: none;">
  <div class="row">

    <div class="col-lg-2"></div>
<!-- You can make it whatever width you want. I'm making it full width
on <= small devices and 4/12 page width on >= medium devices -->
<div class="col-xs-12 col-lg-10" style="padding-top: 100px;">


<!-- CREDIT CARD FORM STARTS HERE -->
<div class="panel panel-default credit-card-box">
<div class="panel-heading display-table" >
<div class="row display-tr" >
<h3 class="panel-title display-td"style="color:white;" >Payment Details</h3>
<div style="display: inline;" class="display-td" >                            
<img class="img-responsive pull-right" src="http://i76.imgup.net/accepted_c22e0.png" style="padding-left: 60px;">
</div>
</div>                    
</div>
<div class="panel-body">
<form role="form" id="payment-form">
<div class="row">
<div class="col-xs-80">
                            
</div>
</div>
<div class="row">
  <div class="form-group">
    <label for="cardNumber" style="color:white;" >CARD NUMBER</label>
    <div  class="input-group" style="padding-left: 20px;">
    <input  
    type="tel"
    class="form-control"
    name="cardNumber"
    placeholder="Valid Card Number"
    autocomplete="cc-number"
    required autofocus 
    />
    <span class="input-group-addon"><i class="fa fa-credit-card"></i></span>
    </div>
    </div>
<div class="col-xs-10 col-md-10">
<div class="form-group">
<label for="cardExpiry"><span class="hidden-xs" style="color:white;" >EXPIRATION</span></label>
<input 
type="tel" 
class="form-control" 
name="cardExpiry"
placeholder="MM / YY"
autocomplete="cc-exp"
required 
/>
</div>
</div>
<div class="col-xs-5 col-md-2 pull-right">
<div class="form-group">
<label for="cardCVC" style="color:white;" >CV CODE</label>
<input 
type="tel" class="form-control"name="cardCVC"placeholder="CVC"autocomplete="cc-csc" required/>
</div>
</div>
</div>
<div class="row">
<div class="col-xs-12 col-md-12">
<div class="form-group">
<label for="couponCode" style="color:white;" >Address</label>
<input type="text" class="form-control" name="Personal Address" />
</div>
</div>                        
</div>
<div class="row" style="padding-left: 20px;">
<div class="col-xs-12" style="padding-top: 10px;"style="padding-left: 20px;">
<p style="text-align: center;">
    <button class="btn btn-primary" onclick="location.href='pages/orderdone.php?<?php echo $id2 ?>'" type="button">
      Proceed to payment</button>
  </p>
</div>
</div>
</form>
</div>
</div>      
<!-- CREDIT CARD FORM ENDS HERE -->


</div>            



</div>
  </div>
  <div id="myDIV1" style="display: none;">
    <div class="row">
  
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <!-- You can make it whatever width you want. I'm making it full width
  on <= small devices and 4/12 page width on >= medium devices -->
  <div class="col-lg-4"></div>
  <div class="col-xs-12 col-lg-10" style="padding-top: 10px;">
  <div class="col-lg-2"></div>
  
  <!-- CREDIT CARD FORM STARTS HERE -->
  <div class="panel panel-default credit-card-box">
  <div class="panel-heading display-table" >
  <div class="row display-tr" >
  <h3 class="panel-title display-td"style="color:white;" >Payment Details</h3>
  <div style="display: inline;" class="display-td" >                            
  <img class="img-responsive pull-right" src="http://i76.imgup.net/accepted_c22e0.png" style="padding-left: 60px;">
  </div>
  </div>                    
  </div>
  <div class="panel-body">
  <form role="form" id="payment-form">
  <div class="row">
  <div class="col-xs-80">
                              
  </div>
  </div>
  <div class="row">
    <div class="form-group">
      <label for="cardNumber" style="color:white;" >Account Number</label>
      <div  class="input-group" style="padding-left: 20px;">
      <input  
      type="tel"
      class="form-control"
      name="cardNumber"
      placeholder="Valid Account Number"
      autocomplete="cc-number"
      required autofocus 
      />
      <span class="input-group-addon"><i class="fa fa-credit-card"></i></span>
      </div>
      </div>
  </div>
  <div class="row" style="padding-left: 20px;">
  <div class="col-xs-12" style="padding-top: 10px;"style="padding-left: 20px;">
  <p style="text-align: center;">
      <button class="btn btn-primary" onclick="location.href='pages/orderdone.php?<?php echo $id2 ?>'" type="button">
        Confirm Payment</button>
    </p>
  </div>
  </div>
  </form>
  </div>
  </div>      
  <!-- CREDIT CARD FORM ENDS HERE -->
  
  
  </div>            
  
  
  
  </div>
    </div>
      </div>
    </div>
  </div>
    
      </div>
    </div>
  </div>
    

    <div class="bgimg" style="background-image: url('images/bg_1.jpg');" data-stellar-background-ratio="0.5">
    </div>
    <footer class="pt-5 pb-4" id="contact">
			<div class="container">
				<div class="row">
					<div class="col-lg-6">
						<h5 class="mb-8 font-weight-bold">ABOUT US</h5><br>
						<ul class="f-address">
							<li>
								<div class="row">
									<div class="col-1"><i class="fas fa-map-marker"></i></div>
                
							</li>
							<li>
								<div class="row">
									<div class="col-1"><i class="far fa-envelope"></i></div>
									<div class="col-10">
										<h6 class="font-weight-bold mb-0">Have any questions?</h6>
										<p><a href="pages/complain.html">Support@universalmart.com</a></p>
									</div>
								</div>
							</li>
							<li>
								<div class="row">
									<div class="col-1"><i class="fas fa-phone-volume"></i></div>
									<div class="col-10">
										<h6 class="font-weight-bold mb-0">Phone No:</h6>
										<p><a href="#">+92 (0) 51-33-33211-33312</a></p>
									</div>
								</div>
              </li>
              
						</ul>
					</div>
					<div class="col-lg-3 col-md-6 col-sm-6 mt-2 mb-4">
						<ul class="f-address">
						</ul>
					</div>
					
          </div>
          
				</div>
			</div>
		</footer>
		<!-- Copyright -->
		<section class="copyright">
			<div class="container">
				<div class="row">
					<div class="col-md-12 ">
						<div class="text-center text-black" style="padding-bottom: 50px;">
							&copy; <strong>2019 Universal Mart. All Rights Reserved.</strong>
						</div>
					</div>
				</div>
			</div>
		</section>
    
  <!-- .site-wrap -->

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.fancybox.min.js"></script>
  <script src="js/jquery.sticky.js"></script>
  <script src="js/jquery.mb.YTPlayer.min.js"></script>




  <script src="js/main.js"></script>

</body>
</html>