<?php
$id2=$_GET['id1'];
$host = "localhost";
$dbUsername = "root";
$dbPassword = "YES";
$dbname = "fyp";
$answer;
//create connection
$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
if (mysqli_connect_error()) {
 die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
} else {

  $SELECT = "SELECT `name` from registration where email = '$id2'";
  $result = $conn->query($SELECT);
  
  $SELECT1 = "SELECT `name` from registration where phone = '$id2'";
  $result1 = $conn->query($SELECT1);

  

//  while ($row = mysql_fetch_assoc($result)) {
   // echo $row['name'];
  //}

//
  if ($result->num_rows > 0){
    while($row = $result->fetch_assoc()) {
      //echo "id: " . $row["name"];
      $answer=$row["name"];
  }
    //$row = mysql_fetch_assoc($result1);
    //echo $row['name'];
    //$answer=$row['name'];
 }
  else if( $result1->num_rows>0) {
    while($row = $result1->fetch_assoc()) {
     // echo "id: " . $row["name"];
      $answer=$row["name"];
  }
    //$row = mysql_fetch_assoc($result1);
    //echo $row['name'];
    //$answer=$row['name'];
  }
}

?>
<!doctype html>
<html lang="en">
  <head>
    <style>
    	/*=-footer-=*/
			footer {
				color: #fff;
				background-attachment: fixed;
				background-color:#222;
        background-image: url(https://s7.postimg.org/uyf0oioaz/footer-bg.png);
				background-size: cover;
				background-position: bottom;
			}
			footer p {
				color: #ccc;				
			}
	   footer a {
				color: #ccc;				
			}
			.social-pet li {
				display: inline-block;
				margin-right: 10px;
			}
			.social-pet li a {
				height: 35px;
				width: 35px;
				border-radius: 50%;
				text-align: center;
				display: block;
				line-height: 35px;
				background-color: #3a5a95;
				color: #fff;
			}
			.social-pet li:nth-child(2) a {
				background-color: #57aced;
			}
			.social-pet li:nth-child(3) a {
				background-color: #dd4f43;
			}
			.social-pet li:nth-child(4) a {
				background-color: #6b27b2;
			}
			.social-pet li a:hover {
				background-color: #0141a2;
			}
			.social-pet li a:hover i {
				transform: rotate(360deg);
				-moz-transform: rotate(360deg);
				-webkit-transform: rotate(360deg);
			}
			.recent-post li {
				display: block;
				color: #ccc;
				margin-bottom: 25px;
			}
			.recent-post li label {
				float: left;
				border: 2px solid #ccc;
				padding: 1px 7px;
				text-align: center;
			}
			.recent-post li label span {
				color: #fff;
			}
			footer .input-group-addon {
				background-color: #0141a2;
				padding: 10px;
			}
			.f-address li {
				display: inline-block;
			}
			.f-address li i {
				color: #2995de;
				font-size: 18px;
			}
			.f-address li a {
				color: #ccc;
			}
			/*=-Copyright-=*/
			.copyright {
				background-color: #111;
				padding: 12px 0;
        font-size:14px;
			}
	<!--animated text-->
   
body {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  background-color: black;
}

.deconstructed {
  position: relative;
  margin: auto;
  height: 0.90em;
  color: transparent;
  font-family: 'Cambay', sans-serif;
  font-size: 5vw;
  font-weight: 700;
  letter-spacing: -0.02em;
  line-height: 1.03em;
}

.deconstructed > div {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  color: #FF0000;
  pointer-events: none;
}

.deconstructed > div:nth-child(1) {
  -webkit-mask-image: linear-gradient(black 25%, transparent 25%);
  mask-image: linear-gradient(black 25%, transparent 25%);
  animation: deconstructed1 5s infinite;
}

.deconstructed > div:nth-child(2) {
  -webkit-mask-image: linear-gradient(transparent 25%, black 25%, black 50%, transparent 50%);
  mask-image: linear-gradient(transparent 25%, black 25%, black 50%, transparent 50%);
  animation: deconstructed2 5s infinite;
}

.deconstructed > div:nth-child(3) {
   -webkit-mask-image: linear-gradient(transparent 50%, black 50%, black 75%, transparent 75%);
  mask-image: linear-gradient(transparent 50%, black 50%, black 75%, transparent 75%);
  animation: deconstructed3 5s infinite;
}

.deconstructed > div:nth-child(4) {
   -webkit-mask-image: linear-gradient(transparent 75%, black 75%);
  mask-image: linear-gradient(transparent 75%, black 75%);
  animation: deconstructed4 5s infinite;
}

@keyframes deconstructed1 {
  0% {
    transform: translateX(100%);
  }
  26% {
    transform: translateX(0%);
  }
  83% {
    transform: translateX(-0.1%);
  }
  100% {
    transform: translateX(-120%);
  }
}

@keyframes deconstructed2 {
  0% {
    transform: translateX(100%);
  }
  24% {
    transform: translateX(0.5%);
  }
  82% {
    transform: translateX(-0.2%);
  }
  100% {
    transform: translateX(-125%);
  }
}

@keyframes deconstructed3 {
  0% {
    transform: translateX(100%);
  }
  22% {
    transform: translateX(0%);
  }
  81% {
    transform: translateX(0%);
  }
  100% {
    transform: translateX(-130%);
  }
}

@keyframes deconstructed4 {
  0% {
    transform: translateX(100%);
  }
  20% {
    transform: translateX(0%);
  }
  80% {
    transform: translateX(0%);
  }
  100% {
    transform: translateX(-135%);
  }
}


		<!--end of animated text -->
   html,
body {
    height: 100%;
    width: 100%;
}



.card {
    
    border-radius: 8px;
    height: 300px;
    width: 300px;
    position: absolute;
    top: 0;
    right: 0;
    left: 0;
    bottom: 0;
    margin: auto;
  background-size: cover;

    background-position: center;
    background-repeat: no-repeat;
    box-shadow: 0 0 80px -10px black;
    overflow: hidden;
}
.card1{

  background-image:url("../images/f2.jpg");

}
.card2{

background-image:url("../images/card1.jpg");
}
.card3{

background-image:url("../images/card2.jpg");
}

.card4{

background-image:url("../images/card3.jpg");
}

.card5{

background-image:url("../images/card4.jpg");
}

.card6{

background-image:url("../images/card5.jpg");
}

.card-blur {
    position: absolute;
    height: 100%;
    width: calc(100% + 1px);
    background-color: black;
    opacity: 0;
    transition: opacity 0.15s ease-in;
}

.card:hover .card-blur {
    opacity: 0.6;
}

.footer {
    z-index: 1;
    position: absolute;
    height: 80px;
    width: 100%;
    bottom: 0;
}

svg#curve {
    position: absolute;
    fill: white;
    left: 0;
    bottom: 0;
    width: 400px;
    height: 450px;
}

.connections {
    height: 80px;
    width: 400px;
    position: absolute;
    left: 0;
    right: 0;
    bottom: 100px;
    margin: auto;
}

.connection {
    height: 25px;
    width: 25px;
    border-radius: 100%;
    background-color: white;
    display: inline-block;
    padding: 5px;
    margin-right: 25px;
    transform: translateY(200px);
    
    transition: transform 1s cubic-bezier(.46, 1.48, .18, .81);
}

.card:hover .connection {
    transform: translateY(0px);
}

.connection.facebook {
    margin-left: 20px;
    padding: 5px;
}

.connection.twitter {
    transition-delay: 0.02s;
}

.connection.behance {
    transition-delay: 0.04s;
}

.connection.facebook .icon {
    height: 18px;
    width: 18px;
    margin-top: 4px;
    margin-left: 4px;
    background-image: url(https://www.xink.io/wp-content/themes/xink/assets/images/icons/black/64/facebook_001.png);
    background-position: center;
    background-size: cover;
}

.connection.twitter .icon {
    height: 100%;
    width: 100%;
    background-image: url(https://www.xink.io/wp-content/themes/xink/assets/images/icons/black/64/instagram_001.png);
    background-position: center;
    background-size: cover;
}

.connection.behance .icon {
    height: 100%;
    width: 100%;
    background-image: url(https://www.xink.io/wp-content/themes/xink/assets/images/icons/black/64/twitter_001.png);
    background-position: center;
    background-size: cover;
}

.info {
	font-family: Inconsolata;
    padding-left: 20px;
    transform: translateY(250px);

    transition: transform 1s cubic-bezier(.31,1.21,.64,1.02);
}

.card:hover .info {
    transform: translateY(0px);
}
.title{
  font-family: 'Times New Roman', Times, serif;
  font-size: 30px;
  color: white;
  font-weight: bold;
  

}

.name {
    font-weight: bolder;
    color:lightsalmon;
    padding-top: 5px;
}

.job {
    margin-top: 10px;
}






    form { 
  display: block;
  margin-top: 0em;
  text-align:right;
}
    </style>
    <titlle></title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <link href="../images/prologo.png" rel="icon" type="image/x-icon" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" type="text/css" href="nav.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="../images/prologo.png" rel="icon" type="image/x-icon" />
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
  </head>
  <body>
  <nav class="nav">
    <div class="container">
    
        <div class="logo">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <a href="../images/mart.png" style="font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;font-style: italic;">ConVet</a>
        </div>
        <div id="mainListDiv" class="main_list">
            <ul class="navlinks">
                <li><a href="#" style="">Home</a></li>
                <li><a href="#">Contact</a></li>
                <li><a href="profile.php?id1=<?php echo $id2 ?>">Profile</a></li>
                <li><a href="#">Logout</a></li>
            </ul>
        </div>
    </div>
    <br>
</div>
</nav>
<section class="home">

    <br><br><br><br><br><br>
    
<div class="row">
  <div class="col-lg-3">
      
  </div>
  <div class="col-lg-6">
      <div id="carouselExampleControls" class="carousel slide" data-ride="carousel" data-interval="2000">
          <div class="carousel-inner">
            <div class="carousel-item active">
              <img src="../images/trans.png" height="300px" width="300px" class="d-block w-100" alt="...">
              <div class="carousel-caption d-none d-md-block">
                  <h5 style="font-size: 40px;font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;">Welcome, <?php echo $answer; ?> to YOur Site !!</h5>
                  <p style="">Where customer need is our highest priority.Get connected to the the concerned and close ones !
                  </p>
                </div>
            </div>
            <div class="carousel-item">
              <img src="../images/delivery.png" height="500px" width="200px" class="d-block w-100" alt="...">
            </div>
          </div>
          <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>
        </div>
  </div>

</div>

</section>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src="js/scripts.js"></script>
<script>
          $(window).scroll(function() {
              if ($(document).scrollTop() > 50) {
                  $('.nav').addClass('affix');
                  console.log("OK");
              } else {
                  $('.nav').removeClass('affix');
              }
          });
          $('.navTrigger').click(function () {
          $(this).toggleClass('active');
          console.log("Clicked menu");
          $("#mainListDiv").toggleClass("show_list");
          $("#mainListDiv").fadeIn();
      
      });
      
      </script>

      <br><br>
      <div class="row">
        <div class="col-lg-4"></div>
        <div class="col-lg-4">
      <h1 style="font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;font-size: 40px;color: rgb(226, 57, 57);
      text-align: center;">
      Select a category</h1>
    </div>
    <br><br><br><br><br>
    </div>

    <div class="row">
    
      <div class="col-lg-4">



<<a href="countdown.html">
      
<div id="curve" class="card card1">
    <div class="footer">
       
        <svg id="curve">
            <!--<path id="p" d="M0,200 Q80,100 400,200 V150 H0 V50" transform="translate(0 300)" />
            -->
              <rect id="dummyRect" x="0" y="0" height="450" width="400"
		  fill="transparent" />
            <!-- slide up-->
            <animate xlink:href="#p" attributeName="d" to="M0,50 Q80,100 400,50 V150 H0 V50" fill="freeze" begin="dummyRect.mouseover" end="dummyRect.mouseout" dur="0.1s" id="bounce1" />
            <!-- slide up and curve in -->
            <animate xlink:href="#p" attributeName="d" to="M0,50 Q80,0 400,50 V150 H0 V50" fill="freeze" begin="bounce1.end" end="dummyRect.mouseout" dur="0.15s" id="bounce2" />
            <!-- slide down and curve in -->
            <animate xlink:href="#p" attributeName="d" to="M0,50 Q80,80 400,50 V150 H0 V50" fill="freeze" begin="bounce2.end" end="dummyRect.mouseout" dur="0.15s" id="bounce3" />
            <!-- slide down and curve out -->
            <animate xlink:href="#p" attributeName="d" to="M0,50 Q80,45 400,50 V150 H0 V50" fill="freeze" begin="bounce3.end" end="dummyRect.mouseout" dur="0.1s" id="bounce4" />
            <!-- curve in -->
            <animate xlink:href="#p" attributeName="d" to="M0,50 Q80,50 400,50 V150 H0 V50" fill="freeze" begin="bounce4.end" end="dummyRect.mouseout" dur="0.05s" id="bounce5" />

            <animate xlink:href="#p" attributeName="d" to="M0,200 Q80,100 400,200 V150 H0 V50" fill="freeze" begin="dummyRect.mouseout" dur="0.15s" id="bounceOut" />
        </svg>
        <div class="info">
          <div class="title">Add Friends</div>
            <div class="name">Get Connected to your close ones ! <img src="../images/veg.png" height="20px"width="20px"></div>
        </div>
    </div>
    <div class="card-blur"></div>
</div>

</a>

</div>

  <div class="col-lg-4">

      <a href="../index.php?id1=<?php echo $id2 ?>">
      
<div id="curve" class="card card2">
    <div class="footer">
       
        <svg id="curve">
           <!-- <path id="p" d="M0,200 Q80,100 400,200 V150 H0 V50" transform="translate(0 300)" />
            -->
            <rect id="dummyRect" x="0" y="0" height="450" width="400"
		  fill="transparent" />
            <!-- slide up-->
            <animate xlink:href="#p" attributeName="d" to="M0,50 Q80,100 400,50 V150 H0 V50" fill="freeze" begin="dummyRect.mouseover" end="dummyRect.mouseout" dur="0.1s" id="bounce1" />
            <!-- slide up and curve in -->
            <animate xlink:href="#p" attributeName="d" to="M0,50 Q80,0 400,50 V150 H0 V50" fill="freeze" begin="bounce1.end" end="dummyRect.mouseout" dur="0.15s" id="bounce2" />
            <!-- slide down and curve in -->
            <animate xlink:href="#p" attributeName="d" to="M0,50 Q80,80 400,50 V150 H0 V50" fill="freeze" begin="bounce2.end" end="dummyRect.mouseout" dur="0.15s" id="bounce3" />
            <!-- slide down and curve out -->
            <animate xlink:href="#p" attributeName="d" to="M0,50 Q80,45 400,50 V150 H0 V50" fill="freeze" begin="bounce3.end" end="dummyRect.mouseout" dur="0.1s" id="bounce4" />
            <!-- curve in -->
            <animate xlink:href="#p" attributeName="d" to="M0,50 Q80,50 400,50 V150 H0 V50" fill="freeze" begin="bounce4.end" end="dummyRect.mouseout" dur="0.05s" id="bounce5" />

            <animate xlink:href="#p" attributeName="d" to="M0,200 Q80,100 400,200 V150 H0 V50" fill="freeze" begin="dummyRect.mouseout" dur="0.15s" id="bounceOut" />
        </svg>
        <div class="info">
          <div class="title">Start a service </div>
            <div class="name">Click here to add more details !</div>
        </div>
    </div>
    <div class="card-blur"></div>
</div>

</a>

  </div>
  <div class="col-lg-4">

      <a href="../news_Feed.php">
      <div id="curve" class="card card3">
          <div class="footer">
             
              <svg id="curve">
                <!--  <path id="p" d="M0,200 Q80,100 400,200 V150 H0 V50" transform="translate(0 300)" />
                -->
                  <rect id="dummyRect" x="0" y="0" height="450" width="400"
            fill="transparent" />
                  <!-- slide up-->
                  <animate xlink:href="#p" attributeName="d" to="M0,50 Q80,100 400,50 V150 H0 V50" fill="freeze" begin="dummyRect.mouseover" end="dummyRect.mouseout" dur="0.1s" id="bounce1" />
                  <!-- slide up and curve in -->
                  <animate xlink:href="#p" attributeName="d" to="M0,50 Q80,0 400,50 V150 H0 V50" fill="freeze" begin="bounce1.end" end="dummyRect.mouseout" dur="0.15s" id="bounce2" />
                  <!-- slide down and curve in -->
                  <animate xlink:href="#p" attributeName="d" to="M0,50 Q80,80 400,50 V150 H0 V50" fill="freeze" begin="bounce2.end" end="dummyRect.mouseout" dur="0.15s" id="bounce3" />
                  <!-- slide down and curve out -->
                  <animate xlink:href="#p" attributeName="d" to="M0,50 Q80,45 400,50 V150 H0 V50" fill="freeze" begin="bounce3.end" end="dummyRect.mouseout" dur="0.1s" id="bounce4" />
                  <!-- curve in -->
                  <animate xlink:href="#p" attributeName="d" to="M0,50 Q80,50 400,50 V150 H0 V50" fill="freeze" begin="bounce4.end" end="dummyRect.mouseout" dur="0.05s" id="bounce5" />
      
                  <animate xlink:href="#p" attributeName="d" to="M0,200 Q80,100 400,200 V150 H0 V50" fill="freeze" begin="dummyRect.mouseout" dur="0.15s" id="bounceOut" />
              </svg>
              <div class="info">
                <div class="title">News Feed</div>
                  <div class="name">Let's explore !<img src="../images/smiley.png" height="30px"width="30px"></div>
              </div>
          </div>
          <div class="card-blur"></div>
      </div>
    </a>
  </div>
    </div>
    <br><br><br>
    <footer class="pt-5 pb-4" id="contact">
			<div class="container">
				<div class="row">
					<div class="col-lg-6">
						<h5 class="mb-8 font-weight-bold">ABOUT US</h5><br>
						<ul class="f-address">
							<li>
								<div class="row">
									<div class="col-1"><i class="fas fa-map-marker"></i></div>
									<div>
                    <p><strong>&nbsp;&nbsp;Shop # 12 Centaurus Mall Islamabad</strong></p><br><br>
                </div>
                
							</li>
							<li>
								<div class="row">
									<div class="col-1"><i class="far fa-envelope"></i></div>
									<div class="col-10">
										<h6 class="font-weight-bold mb-0">Have any questions?</h6>
										<p><a href="complain.html">Support@universalmart.com</a></p>
									</div>
								</div>
							</li>
							<li>
								<div class="row">
									<div class="col-1"><i class="fas fa-phone-volume"></i></div>
									<div class="col-10">
										<h6 class="font-weight-bold mb-0">Phone No:</h6>
										<p><a href="#">+92 (0) 51-33-33211-33312</a></p>
									</div>
								</div>
              </li>
              
						</ul>
					</div>
					<div class="col-lg-3 col-md-6 col-sm-6 mt-2 mb-4">
						<ul class="f-address">
						</ul>
					</div>
						<ul class="social-pet mt-4">
            <h5>Social Links</h5><br>
							<li><a href="https://www.facebook.com/faisal.ashfaq3" title="facebook"><i class="fab fa-facebook-f"></i></a></li>
							<li><a href="https://www.twitter.com" title="twitter"><i class="fab fa-twitter"></i></a></li>
							<li><a href="https://www.google.com" title="google-plus"><i class="fab fa-google-plus-g"></i></a></li>
              <li><a href="https://www.instagram.com" title="instagram"><i class="fab fa-instagram"></i></a></li>
              <h5><strong><br>Partners<br><br></strong><img src="../images/uber.png" height="100px" width="200px"></h5>
            </ul>
            
          </div>
          
				</div>
			</div>
		</footer>
		<!-- Copyright -->
		<section class="copyright">
			<div class="container">
				<div class="row">
					<div class="col-md-12 ">
						<div class="text-center text-white">
							&copy; 2019 Universal Mart. All Rights Reserved.
						</div>
					</div>
				</div>
			</div>
		</section>
    

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>