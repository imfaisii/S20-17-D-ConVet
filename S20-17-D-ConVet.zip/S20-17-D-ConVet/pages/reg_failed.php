<?php
$name1=$_GET['name1'];
$password1=$_GET['password1'];
$phone1=$_GET['phone1'];
$address1=$_GET['address1'];



?>
<!doctype html>
<html lang="en">
  <head>
    <title>Registration
    </title>
    <style>
        .tab{margin-left: 74px;}

        
        
    </style>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Colorlib Templates">
    <meta name="author" content="Colorlib">
    <meta name="keywords" content="Colorlib Templates">

    <!-- Title Page-->
    <!-- Icons font CSS-->
    <link href="../vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="../vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="../vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="../vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="../css/main.css" rel="stylesheet">
    <link href="../images/prologo.png" rel="icon" type="image/x-icon" />


    <!-- for password visibility -->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

<script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-show-password/1.0.3/bootstrap-show-password.min.js"></script>

    <script type="text/javascript">
        function redirect()
        {
            if (window.confirm('Successfully Registered ! LOGIN'))
            {
                return location.href = "https://www.google.com";
            }
            else
            {
                return;
            }   

        };




        
        
        function validateForm() 
                    {
                 
                  var x = document.forms["myForm"]["name"].value;
                  var y = document.forms["myForm"]["pass"].value;
                  var z = document.forms["myForm"]["email1"].value;
                  var q = document.forms["myForm"]["addr"].value;
                  var q = document.forms["myForm"]["phone"].value;
                  if (x == "") 
                          {
                alert("Please enter Username");
                return false;
                          }
                          else if (y == "") 
                          {
                            alert("Please enter Password");
                return false;
                          }
                          else if (z == "") 
                          {
                            alert("Please enter Email");
                            return false;
                          }
                          else if (q == "") 
                          {
                            alert("Please enter Address");
                            return false;
                          }
                          else
                          {
                              redirect();
                          }
                    }
                       //bootstrap toogle
                       $("#password").password('toggle');
                   </script>
  </head>
  <body>
        
      <div class="page-wrapper bg-red font-robo">
            <div class="wrapper wrapper--w960">
                <br><br>
                <div class="card card-2">
                    <div class="card-heading">
                            
                    </div>
                    <div class="card-body">
                        
                        <h4 class="title" style="display: inline;"><h3 style="display: inline;text-align: center;">Register Now</h3> <br><strong class="" style="display: inline;"><br>Failed !</strong><br><br>
                        </h4>
                        <label style="color: red;font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;font-style: italic;">
                        * The Email you entered is already registered by someone </label>
                        <form action="registration.php" name="myForm" method="POST">
                        <div class="row row-space">
                                <div class="col-2">
                                    <div class="input-group">
                                            <input name="name" id=""class="input--style-2" type="text" value="<?php echo $name1; ?>" placeholder="Name" name="name" required>
                                    </div>
                                </div>
                                <div class="col-2">
                                           <input name="pass" class="input--style-2" data-toggle="password" id="password" type="password" value="<?php echo $password1; ?>" pattern=".{6,}" title="Six or more characters" placeholder="Password" name="password" required>
                                    
                                </div>
                            </div>
                            <div class="row row-space">
                                <div class="col-2">
                                    <div class="input-group">
                                        <input class="input--style-2 js-datepicker" type="text" placeholder="Birthdate" name="birthday">
                                        <i class="zmdi zmdi-calendar-note input-icon js-btn-calendar"></i>
                                    </div>
                                </div>
                                <div class="col-2">
                                    <div class="input-group">
                                        <div class="rs-select2 js-select-simple select--no-search">
                                            <select name="gender">
                                                <option disabled="disabled" selected="selected">Gender</option>
                                                <option>Male</option>
                                                <option selected>Female</option>
                                                <option>Others</option>
                                            </select>
                                            <div class="select-dropdown"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="input-group">
                                    <input name="addr"class="input--style-2" type="text" value="<?php echo $address1; ?>" placeholder="Address" required>
                            </div>
                            
                            <div class="input-group">
                                <input name="email1" class="input--style-2" type="email" pattern="[A-Za-z,@,.]{6,}" title="must have @"  placeholder="Email" required>
                        </div>
                        <div class="input-group">
                            <input name="phone" class="input--style-2" type="text"  placeholder="Phone No" value="<?php echo $phone1; ?>" min="0" maxlength="11" pattern="[0-9]{11}" title="Phone number of 11 digits" required>
                    </div>
                            <div class="p-t-30">
                                <input style="color:red;" class="btn btn-danger" type="submit" value="Register">
                                
                            </div>
                            
                        </form>
                    </div>
                </div>
                <br><br>
            </div>
        </div>
    
    <!-- Optiona
    l JavaScript -->
    <!-- Jquery JS-->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="../vendor/select2/select2.min.js"></script>
    <script src="../vendor/datepicker/moment.min.js"></script>
    <script src="../vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="../js/global.js"></script>
  </body>
</html>