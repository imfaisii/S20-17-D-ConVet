
<!doctype html>
<html lang="en">

<head>
  <title>ConVet &mdash; Connecting People</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  
  <link href="https://fonts.googleapis.com/css?family=Muli:300,400,700,900" rel="stylesheet">
  <link rel="stylesheet" href="fonts/icomoon/style.css">

  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/jquery-ui.css">
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">

  <link rel="stylesheet" href="css/jquery.fancybox.min.css">

  <link rel="stylesheet" href="css/bootstrap-datepicker.css">

  <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

  <link rel="stylesheet" href="css/aos.css">
  <link href="css/jquery.mb.YTPlayer.min.css" media="all" rel="stylesheet" type="text/css">

  <link rel="stylesheet" href="css/style.css">



</head>
<style>
  table {
border-collapse: collapse;
width: 100%;
color: #C74327;
font-family: monospace;
font-size: 25px;
text-align: left;
}
th {
background-color: #C74327;
color: white;
}
tr:nth-child(even) {background-color: #f2f2f2}
</style>
<script>
  var $form = $('#payment-form');
$form.on('submit', payWithStripe);

/* If you're using Stripe for payments */
function payWithStripe(e) {
e.preventDefault();

/* Visual feedback */
$form.find('[type=submit]').html('Validating <i class="fa fa-spinner fa-pulse"></i>');

var PublishableKey = 'pk_test_b1qXXwATmiaA1VDJ1mOVVO1p'; // Replace with your API publishable key
Stripe.setPublishableKey(PublishableKey);

/* Create token */
var expiry = $form.find('[name=cardExpiry]').payment('cardExpiryVal');
var ccData = {
   number: $form.find('[name=cardNumber]').val().replace(/\s/g,''),
   cvc: $form.find('[name=cardCVC]').val(),
   exp_month: expiry.month, 
   exp_year: expiry.year
};

Stripe.card.createToken(ccData, function stripeResponseHandler(status, response) {
   if (response.error) {
       /* Visual feedback */
       $form.find('[type=submit]').html('Try again');
       /* Show Stripe errors on the form */
       $form.find('.payment-errors').text(response.error.message);
       $form.find('.payment-errors').closest('.row').show();
   } else {
       /* Visual feedback */
       $form.find('[type=submit]').html('Processing <i class="fa fa-spinner fa-pulse"></i>');
       /* Hide Stripe errors on the form */
       $form.find('.payment-errors').closest('.row').hide();
       $form.find('.payment-errors').text("");
       // response contains id and card, which contains additional card details            
       console.log(response.id);
       console.log(response.card);
       var token = response.id;
       // AJAX - you would send 'token' to your server here.
       $.post('/account/stripe_card_token', {
               token: token
           })
           // Assign handlers immediately after making the request,
           .done(function(data, textStatus, jqXHR) {
               $form.find('[type=submit]').html('Payment successful <i class="fa fa-check"></i>').prop('disabled', true);
           })
           .fail(function(jqXHR, textStatus, errorThrown) {
               $form.find('[type=submit]').html('There was a problem').removeClass('success').addClass('error');
               /* Show Stripe errors on the form */
               $form.find('.payment-errors').text('Try refreshing the page and trying again.');
               $form.find('.payment-errors').closest('.row').show();
           });
   }
});
}
/* Fancy restrictive input formatting via jQuery.payment library*/
$('input[name=cardNumber]').payment('formatCardNumber');
$('input[name=cardCVC]').payment('formatCardCVC');
$('input[name=cardExpiry').payment('formatCardExpiry');

/* Form validation using Stripe client-side validation helpers */
jQuery.validator.addMethod("cardNumber", function(value, element) {
return this.optional(element) || Stripe.card.validateCardNumber(value);
}, "Please specify a valid credit card number.");

jQuery.validator.addMethod("cardExpiry", function(value, element) {    
/* Parsing month/year uses jQuery.payment library */
value = $.payment.cardExpiryVal(value);
return this.optional(element) || Stripe.card.validateExpiry(value.month, value.year);
}, "Invalid expiration date.");

jQuery.validator.addMethod("cardCVC", function(value, element) {
return this.optional(element) || Stripe.card.validateCVC(value);
}, "Invalid CVC.");

validator = $form.validate({
rules: {
   cardNumber: {
       required: true,
       cardNumber: true            
   },
   cardExpiry: {
       required: true,
       cardExpiry: true
   },
   cardCVC: {
       required: true,
       cardCVC: true
   }
},
highlight: function(element) {
   $(element).closest('.form-control').removeClass('success').addClass('error');
},
unhighlight: function(element) {
   $(element).closest('.form-control').removeClass('error').addClass('success');
},
errorPlacement: function(error, element) {
   $(element).closest('.form-group').append(error);
}
});

paymentFormReady = function() {
if ($form.find('[name=cardNumber]').hasClass("success") &&
   $form.find('[name=cardExpiry]').hasClass("success") &&
   $form.find('[name=cardCVC]').val().length > 1) {
   return true;
} else {
   return false;
}
}

$form.find('[type=submit]').prop('disabled', true);
var readyInterval = setInterval(function() {
if (paymentFormReady()) {
   $form.find('[type=submit]').prop('disabled', false);
   clearInterval(readyInterval);
}
}, 250);
</script>
<style>
  input[type=radio] {
    width: 20px;
    height: 20px;
}
</style>
<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">

  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>


    <header class="site-navbar py-4 js-sticky-header site-navbar-target" role="banner">

      <div class="container-fluid">
        <div class="d-flex align-items-center">
          <div class="site-logo"><a href="index.html">News Feed<span>.</span> </a></div>
          <div class="ml-auto">
            <nav class="site-navigation position-relative text-right" role="navigation">
              <ul class="site-menu main-menu js-clone-nav mr-auto d-none d-lg-block">
                <li><a href="pages/home.php" class="nav-link">Home</a></li>
                <li><a href="#services-section" class="nav-link">Services</a></li>
                <li><a href="#schedule-section" class="nav-link">Schedule</a></li>
                <li><a href="#contact-section" class="nav-link">Payment</a></li>
              </ul>
            </nav>
            <a href="#" class="d-inline-block d-lg-none site-menu-toggle js-menu-toggle float-right"><span class="icon-menu h3"></span></a>
          </div>

        </div>
      </div>

    </header>


    <div class="intro-section" id="home-section" style="background-color: #ccc;">

      <div class="container">

        <div class="row align-items-center">
          <div class="col-lg-12 mx-auto text-center" data-aos="fade-up">
            <h1 class="mb-3">Your News Feed</h1>
            <p class="lead mx-auto desc mb-5">Here you will find all the active/deactivated services. Enjoy ! 
            </p>
            <p class="text-center">
              <a href="#services-section" class="btn btn-outline-white py-3 px-5">Get Started</a>
            </p>
          </div>
        </div>

      </div>
    </div>


    <div class="site-section" id="services-section">
      <div class="container">
        <div class="row justify-content-center text-center mb-5" data-aos="fade-up">
          <div class="col-md-8  section-heading">
            <h2 class="heading mb-3">Services</h2>
            
          </div>
        </div>
        <?php
        $servername = "localhost";
        $username = "username";
        $password = "qwerty";
        $dbname = "fyp";
        
        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        
        $sql = "SELECT serviceName, Date, startedBy FROM services";
        $result = $conn->query($sql);
        echo "<table border='1'>
              <tr>
              <th>Service Name</th>
              <th>Date of Action</th>
              <th>Started By</th>
              </tr>";
        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
              echo "<tr>";
              echo "<td>" . $row['serviceName'] . "</td>";
              echo "<td>" . $row['Date'] . "</td>";
              echo "<td>" . $row['startedBy'] . "</td>";
              echo "</tr>";
              }
              echo "</table>";
              echo "<br><br>";
                }
        else {
            echo "0 results";
        }
        
        $conn->close();
        ?>
        
    <div class="bgimg" style="background-image: url('images/bg_1.jpg');" data-stellar-background-ratio="0.5">
    </div>
    <footer class="pt-5 pb-4" id="contact">
			<div class="container">
				<div class="row">
					<div class="col-lg-6">
						<h5 class="mb-8 font-weight-bold">ABOUT US</h5><br>
						<ul class="f-address">
							<li>
								<div class="row">
									<div class="col-1"><i class="fas fa-map-marker"></i></div>
                
							</li>
							<li>
								<div class="row">
									<div class="col-1"><i class="far fa-envelope"></i></div>
									<div class="col-10">
										<h6 class="font-weight-bold mb-0">Have any questions?</h6>
										<p><a href="pages/complain.html">Support@universalmart.com</a></p>
									</div>
								</div>
							</li>
							<li>
								<div class="row">
									<div class="col-1"><i class="fas fa-phone-volume"></i></div>
									<div class="col-10">
										<h6 class="font-weight-bold mb-0">Phone No:</h6>
										<p><a href="#">+92 (0) 51-33-33211-33312</a></p>
									</div>
								</div>
              </li>
              
						</ul>
					</div>
					<div class="col-lg-3 col-md-6 col-sm-6 mt-2 mb-4">
						<ul class="f-address">
						</ul>
					</div>
					
          </div>
          
				</div>
			</div>
		</footer>
		<!-- Copyright -->
		<section class="copyright">
			<div class="container">
				<div class="row">
					<div class="col-md-12 ">
						<div class="text-center text-black" style="padding-bottom: 50px;">
							&copy; <strong>2019 Universal Mart. All Rights Reserved.</strong>
						</div>
					</div>
				</div>
			</div>
		</section>
    
  <!-- .site-wrap -->

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.fancybox.min.js"></script>
  <script src="js/jquery.sticky.js"></script>
  <script src="js/jquery.mb.YTPlayer.min.js"></script>




  <script src="js/main.js"></script>

</body>
</html>