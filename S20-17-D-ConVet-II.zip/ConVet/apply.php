<?php
session_start();
$id2=$_SESSION['id'];
$serviceName=$_GET['serviceName'];
$date1=$_GET['date'];
$id=$_GET['id'];


$serviceBy=$_GET['serviceBy'];
$servername = "localhost";
$username = "username";
$password = "qwerty";
$dbname = "fyp";
        
        // Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $INSERT1="SELECT `joinedBy` FROM `appliedusers` WHERE  `joinedBy`='$id2' AND `id`='$id'";   // $select * from `appliedusers` where `joinedBy`=$id && ``; -->        
    $result = $conn->query($INSERT1);
    if ($result->num_rows > 0) {
        //echo "o  bhai bawala hoga kiaa.. Dobara join krni ??";
        $result = $conn -> query($INSERT1) or trigger_error($conn -> error." ".$INSERT1);
        header('location:news_feed.php');
        //header("refresh:3,url=news_feed.php?");
}else{
    $INSERT = "INSERT INTO `appliedusers`(`appliedFor`, `date`, `serviceBy`,`joinedBy`,`id`) VALUES ('$serviceName','$date1','$serviceBy','$id2','$id')";
//mysqli_query($conn, $INSERT);
//echo "else";
//echo "<h1> $id </h1>";
$result = $conn -> query($INSERT) or trigger_error($conn -> error." ".$INSERT);
$conn->close();
header('location:news_feed.php');
//header("refresh:8,url=news_feed.php?");

    
}
?>