<!doctype html>
<html lang="en">
  <head>
    <title>Registration
    </title>
    <style>
.dropbtn {
  background-color: #4CAF50;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
  cursor: pointer;
}

.dropbtn:hover, .dropbtn:focus {
  background-color: #3e8e41;
}

#myInput {
  box-sizing: border-box;
  background-image: url('searchicon.png');
  background-position: 14px 12px;
  background-repeat: no-repeat;
  font-size: 16px;
  padding: 14px 20px 12px 45px;
  border: none;
  border-bottom: 1px solid #ddd;
}

#myInput:focus {outline: 3px solid #ddd;}

.dropdown {
  position: relative;
  display: inline-block;

}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f6f6f6;
  min-width: 230px;
  overflow: auto;
  border: 1px solid #ddd;
  z-index: 1;
  height:300px;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  size:5;
}

.dropdown a:hover {background-color: #ddd;}

.show {display: block;}
</style>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Colorlib Templates">
    <meta name="author" content="Colorlib">
    <meta name="keywords" content="Colorlib Templates">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Title Page-->
    <!-- Icons font CSS-->
    <link href="../vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="../vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="../vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="../vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="../css/main.css" rel="stylesheet">
    <link href="../images/prologo.png" rel="icon" type="image/x-icon" />

    <!-- for bootstrap toogle-->
	
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script src="http://code.jquery.com/jquery-latest.js"></script>
	<script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-show-password/1.0.3/bootstrap-show-password.min.js"></script>





    <script type="text/javascript">
        function redirect()
        {
            if (window.confirm('Successfully Registered ! LOGIN'))
            {
                return location.href = "https://www.google.com";
            }
            else
            {
                return;
            }   

        };

            // js script to see password through a check box tick
        function myFunction() {
    var x = document.getElementById("myInput");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
        function validateForm() 
                    {
                 
                  var x = document.forms["myForm"]["name"].value;
                  var y = document.forms["myForm"]["pass"].value;
                  var z = document.forms["myForm"]["email1"].value;
                  var q = document.forms["myForm"]["addr"].value;
                  var q = document.forms["myForm"]["phone"].value;
                  if (x == "") 
                          {
                alert("Please enter Username");
                return false;
                          }
                          else if (y == "") 
                          {
                            alert("Please enter Password");
                return false;
                          }
                          else if (z == "") 
                          {
                            alert("Please enter Email");
                            return false;
                          }
                          else if (q == "") 
                          {
                            alert("Please enter Address");
                            return false;
                          }
                          else
                          {
                              redirect();
                          }
                    }
                    
                    //bootstrap toogle
                    $("#password").password('toggle');

                   </script>
  </head>
  <body>
        
      <div class="page-wrapper bg-red font-robo">
            <div class="wrapper wrapper--w960">
                <br><br>
                <div class="card card-2">
                    <div class="card-heading">
                            
                    </div>
                    <div class="card-body">
                        
                        <h4 class="title" style="display: inline;"><h3 style="display: inline;text-align: center;">Register Now</h3> <br><strong class="" style="display: inline;"><br>Get Registered</strong><br><br>
                        </h4>
						<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>

</script>

                        <form action="registration.php" name="myForm" method="POST" enctype="multipart/form-data">
                        <div class="row row-space">
                                <div class="col-2">
                                    <div class="input-group">
                                            <input name="name" id=""class="input--style-2"  type="text" placeholder="Name" name="name" required autofocus>
                                    </div>
                                </div>
                                <div class="col-2">
                                        <input class="input--style-2" data-toggle="password" type="password" id="password"   pattern=".{6,}" title="Six or more characters" placeholder="Password" name="password" required>
                                
                                </div>
                            </div>
                            <div class="row row-space">
                                <div class="col-2">
                                    <div class="input-group">
                                        <input class="input--style-2 js-datepicker" type="text" placeholder="Birthdate" name="birthday">
                                        <i class="zmdi zmdi-calendar-note input-icon js-btn-calendar"></i>
                                    </div>
                                </div>
                                <div class="col-2">
                                    <div class="input-group">
                                        <div class="rs-select2 js-select-simple select--no-search">
                                            <select name="gender" >
                                                <option disabled="disabled" selected="selected" >Gender</option>
                                                <option >Male </option>
                                                <option >Female</option>
                                                <option>Others</option>
                                            </select> 
                                            <div class="select-dropdown"></div>
                                        </div>
                                    </div>
									<div class="input-group">
                                        <div class="rs-select2 js-select-simple select--no-search">
                                            <select name="registrationType" >
                                                <option disabled="disabled" selected="selected" >Registration Type</option>
                                                <option >Veteran</option>
                                                <option >Organization</option>
                                            </select> 
                                            <div class="select-dropdown"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="input-group">
                                <input name="addr"class="input--style-2" type="text" size="50" placeholder="Address" required>
                        </div>
						
                        <div class="input-group">
                            <div class="dropdown">
							<input type="hidden" id="skills" name="skills"/>
							
<button onclick="myFunction()" style="border-radius:8px;" class="dropbtn">Add Skills</button>
  
  <div id="myDropdown" class="dropdown-content" size="5">
    <input type="text" placeholder="Search.." id="myInput" onkeyup="filterFunction()">
    
	<?php
$myfile = fopen("skills.txt", "r") or die("Unable to open file!");
// Output one line until end-of-file
while(!feof($myfile)) {
	$value=fgets($myfile); ?>
  <a href='javascript:myFunction1("<?php echo $value; ?>");'><?php echo $value; ?> </a>
  <?php
 
}
fclose($myfile);
?>
  </div>
</div>
<br><br>
<p style=""id="demo"></p>


<script>
var skills="";
var editedText="";
document.getElementById("demo").innerHTML = skills;

function myFunction1(y) {
  skills+=y+",";
  editedText = skills.slice(0, -1)
  document.getElementById("demo").innerHTML = "You  have added : "+editedText;
  document.getElementById("skills").value =  editedText;
  //alert("Added "+y);
}
$(document).ready(function(){
  $("button").click(function(){
	  //alert(editedText);
	  $.get("http://localhost:5000/predict?skills="+editedText);
});
  });
</script>

<script>
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

function filterFunction() {
  var input, filter, ul, li, a, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  div = document.getElementById("myDropdown");
  a = div.getElementsByTagName("a");
  for (i = 0; i < a.length; i++) {
    txtValue = a[i].textContent || a[i].innerText;
    if (txtValue.toUpperCase().indexOf(filter) > -1) {
      a[i].style.display = "";
    } else {
      a[i].style.display = "none";
    }
  }
}
</script>
							<div class="col-2">
                                    <div class="input-group">
                                        <div class="rs-select2 js-select-simple select--no-search">
                                            <select name="skillLevel" >
                                                <option disabled="disabled" selected="selected" >Overall Skill Level</option>
                                                <option >1</option>
                                                <option >2</option>
                                                <option>3</option>
												<option>4</option>
												<option>5</option>
                                            </select> 
                                            <div class="select-dropdown"></div>
                                        </div>
                                    </div>
                    </div>
   
                            <div class="input-group">
                                <input name="email1" class="input--style-2" type="email" size="50" pattern="[A-Za-z,@,.].{6,}" title="must have @" placeholder="Email" required>
                        </div>
                        <div class="input-group">
                            <input name="phone" class="input--style-2" type="text" size="50" placeholder="Phone No" min="0"pattern="[0-9]{11}" title="Phone number of 11 digits"  title="Phone number" required>
                    </div>
					<div >
					Select image to upload:
  <input type="file" name="fileToUpload" id="fileToUpload" required>
  </div>
                            <div class="p-t-30">
                                
                               <input style="color:white;" class="btn btn-danger" type="submit" value="Sign up">
                                
                            </div>
                            
                        </form>
						<!--<button class="btn btn-primary">Confirm Your skill!</button>-->
                    </div>
                </div>
                <br><br>
            </div>
        </div>
    
    <!-- Optiona
    l JavaScript -->
    <!-- Jquery JS-->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="../vendor/select2/select2.min.js"></script>
    <script src="../vendor/datepicker/moment.min.js"></script>
    <script src="../vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="../js/global.js"></script>
  </body>
</html>