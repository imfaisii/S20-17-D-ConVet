<?php
session_start();
$id2=$_SESSION['id'];
$host = "localhost";
$dbUsername = "root";
$dbPassword = "qwerty";
$dbname = "fyp";

//create connection
$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
if (mysqli_connect_error()) {
 die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
} else {
  $sql = "SELECT name FROM `registration` where `name` = 'Faisal'";
  $result = $conn->query($sql);
  
  
  
  
  while($row = $result->fetch_assoc()) {
      
      $Name=$row['name'];
      
	  }


	  $sql1 = "SELECT count(name) as user FROM `registration` ";
	  $result1 = $conn->query($sql1);
	  
	  
	  
	  
	  while($row = $result1->fetch_assoc()) {
		  
		  $users=$row['user'];
		  
		  }
	  
		  $sql2 = "SELECT count(serviceName) as user FROM `services` ";
		  $result2 = $conn->query($sql2);
		  
		  
		  
		  
		  while($row = $result2->fetch_assoc()) {
			  
			  $services=$row['user'];
			  
			  }
		  
			  $sql3 = "SELECT count(joinedBy) as user FROM `appliedusers` ";
			  $result3 = $conn->query($sql3);
			  
			  
			  
			  
			  while($row = $result3->fetch_assoc()) {
				  
				  $appliedpeople=$row['user'];
				  
				  }
			  
    }
?>
<!doctype html>
<html lang="en">
  <head>
  	<title>Admin panel</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css1/style.css">
	<style>
		.border-box{
			border: 1px light black;
		  box-sizing: border-box;
		  border-style:solid solid none;
		  background-color:#fffff
		}
		.center{
			text-align:center;

		}
		Tools
Sign In
Search
Bootstrap Search
Bootstrap search is a component which enables the user to find words, sentences, and numbers in a collection of documents, web pages or other sources.

It can be implemented with buttons or icons, than placed as an input or in a navbar for an even better user experience.

Examples of Bootstrap search use:

Databases
Search engines
Built-in search box on a documentation page (like the one on the left)
You can use the Material Design version or the default Bootstrap style.

Basic example
Search
HTML
<!-- Search form -->
<div class="md-form mt-0">
  <input class="form-control" type="text" placeholder="Search" aria-label="Search">
</div>
Search
HTML
<!-- Search form -->
<input class="form-control" type="text" placeholder="Search" aria-label="Search">
Search with colorful border
Always colorful or only in the :focus state.

Search
Search
Search
Search
Search
Search
HTML
CSS
<!-- Search form -->
<div class="md-form active-pink active-pink-2 mb-3 mt-0">
  <input class="form-control" type="text" placeholder="Search" aria-label="Search">
</div>
<!-- Search form -->
<div class="md-form active-purple active-purple-2 mb-3">
  <input class="form-control" type="text" placeholder="Search" aria-label="Search">
</div>
<!-- Search form -->
<div class="md-form active-cyan active-cyan-2 mb-3">
  <input class="form-control" type="text" placeholder="Search" aria-label="Search">
</div>

<!-- Search form -->
<div class="md-form active-pink-2 mb-3">
  <input class="form-control" type="text" placeholder="Search" aria-label="Search">
</div>
<!-- Search form -->
<div class="md-form active-purple-2 mb-3">
  <input class="form-control" type="text" placeholder="Search" aria-label="Search">
</div>
<!-- Search form -->
<div class="md-form active-cyan-2 mb-3">
  <input class="form-control" type="text" placeholder="Search" aria-label="Search">
</div>
Search
Search
Search
Search
Search
Search
HTML
CSS
<!-- Search form -->
<div class="active-pink-3 active-pink-4 mb-4">
  <input class="form-control" type="text" placeholder="Search" aria-label="Search">
</div>
<!-- Search form -->
<div class="active-purple-3 active-purple-4 mb-4">
  <input class="form-control" type="text" placeholder="Search" aria-label="Search">
</div>
<!-- Search form -->
<div class="active-cyan-3 active-cyan-4 mb-4">
  <input class="form-control" type="text" placeholder="Search" aria-label="Search">
</div>

<!-- Search form -->
<div class="active-pink-4 mb-4">
  <input class="form-control" type="text" placeholder="Search" aria-label="Search">
</div>
<!-- Search form -->
<div class="active-purple-4 mb-4">
  <input class="form-control" type="text" placeholder="Search" aria-label="Search">
</div>
<!-- Search form -->
<div class="active-cyan-4 mb-4">
  <input class="form-control" type="text" placeholder="Search" aria-label="Search">
</div>
Search with icon
Always colorful or only in the :focus state.

Search
Search
Search
Search
Search
Search
Search
Search
HTML
CSS
<!-- Search form -->
<form class="form-inline d-flex justify-content-center md-form form-sm mt-0">
  <i class="fas fa-search" aria-hidden="true"></i>
  <input class="form-control form-control-sm ml-3 w-75" type="text" placeholder="Search"
    aria-label="Search">
</form>

<!-- Search form -->
<form class="form-inline d-flex justify-content-center md-form form-sm active-pink active-pink-2 mt-2">
  <i class="fas fa-search" aria-hidden="true"></i>
  <input class="form-control form-control-sm ml-3 w-75" type="text" placeholder="Search"
    aria-label="Search">
</form>

<!-- Search form -->
<form class="form-inline d-flex justify-content-center md-form form-sm active-purple active-purple-2 mt-2">
  <i class="fas fa-search" aria-hidden="true"></i>
  <input class="form-control form-control-sm ml-3 w-75" type="text" placeholder="Search"
    aria-label="Search">
</form>

<!-- Search form -->
<form class="form-inline d-flex justify-content-center md-form form-sm active-cyan active-cyan-2 mt-2">
  <i class="fas fa-search" aria-hidden="true"></i>
  <input class="form-control form-control-sm ml-3 w-75" type="text" placeholder="Search"
    aria-label="Search">
</form>

<!-- Search form -->
<form class="form-inline d-flex justify-content-center md-form form-sm">
  <input class="form-control form-control-sm mr-3 w-75" type="text" placeholder="Search"
    aria-label="Search">
  <i class="fas fa-search" aria-hidden="true"></i>
</form>

<!-- Search form -->
<form class="form-inline d-flex justify-content-center md-form form-sm active-pink-2 mt-2">
  <input class="form-control form-control-sm mr-3 w-75" type="text" placeholder="Search"
    aria-label="Search">
  <i class="fas fa-search" aria-hidden="true"></i>
</form>

<!-- Search form -->
<form class="form-inline d-flex justify-content-center md-form form-sm active-purple-2 mt-2">
  <input class="form-control form-control-sm mr-3 w-75" type="text" placeholder="Search"
    aria-label="Search">
  <i class="fas fa-search" aria-hidden="true"></i>
</form>

<!-- Search form -->
<form class="form-inline d-flex justify-content-center md-form form-sm active-cyan-2 mt-2">
  <input class="form-control form-control-sm mr-3 w-75" type="text" placeholder="Search"
    aria-label="Search">
  <i class="fas fa-search" aria-hidden="true"></i>
</form>
Search
Search
Search
Search
Search
Search
Search
Search
HTML
CSS
.active-pink-2 input[type=text]:focus:not([readonly]) {
  border-bottom: 1px solid #f48fb1;
  box-shadow: 0 1px 0 0 #f48fb1;
}
.active-pink input[type=text] {
  border-bottom: 1px solid #f48fb1;
  box-shadow: 0 1px 0 0 #f48fb1;
}
.active-purple-2 input[type=text]:focus:not([readonly]) {
  border-bottom: 1px solid #ce93d8;
  box-shadow: 0 1px 0 0 #ce93d8;
}
.active-purple input[type=text] {
  border-bottom: 1px solid #ce93d8;
  box-shadow: 0 1px 0 0 #ce93d8;
}
.active-cyan-2 input[type=text]:focus:not([readonly]) {
  border-bottom: 1px solid #4dd0e1;
  box-shadow: 0 1px 0 0 #4dd0e1;
}
.active-cyan input[type=text] {
  border-bottom: 1px solid #4dd0e1;
  box-shadow: 0 1px 0 0 #4dd0e1;
}
.active-cyan .fa, .active-cyan-2 .fa {
  color: #4dd0e1;
}
.active-purple .fa, .active-purple-2 .fa {
  color: #ce93d8;
}
.active-pink .fa, .active-pink-2 .fa {
  color: #f48fb1;
}
		</style>
	</head>
  <body>
		
		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<div class="custom-menu">
					<button type="button" id="sidebarCollapse" class="btn btn-primary">
	          <i class="fa fa-bars"></i>
	          <span class="sr-only">Toggle Menu</span>
	        </button>
        </div>
				<div class="p-4">
		  		<h1><a href="#" class="logo">ConVet <span>Enjoy your oldage!</span></a></h1>
	        <ul class="list-unstyled components mb-5">
	          <li class="active">
	            <a href="admin.php?id= <?php echo $id2?>"><span class="fa fa-home mr-3"></span> Home</a>
	          </li>
	          <li>
	              <a href="admin_user.php"><span class="fa fa-user mr-3"></span> Users</a>
	          </li>
	          <li>
              <a href="admin_services.php"><span class="fa fa-briefcase mr-3"></span> Services</a>
	          </li>
	          <li>
              <a href="#"><span class="fa fa-sticky-note mr-3"></span> Blog</a>
	          </li>
	          <li>
              <a href="#"><span class="fa fa-suitcase mr-3"></span> Gallery</a>
	          </li>
	          <li>
              <a href="#"><span class="fa fa-cogs mr-3"></span> Services</a>
	          </li>
	          <li>
              <a href="#"><span class="fa fa-paper-plane mr-3"></span> Contacts</a>
	          </li>
	        </ul>

	        <div class="mb-5">
						
	            

	       

	      </div>
    	</nav>

        <!-- Page Content  -->
      <div id="content" class="p-4 p-md-5 pt-5">
		<h2 class="mb-4">Welcome to Admin Panel</h2>
		<p>Hi <?php echo $Name;?>, Here you can manage the convet</p>
			<div class="row">
				<div class="col-lg-3">
					<h1 class="border-box">Users</h1>
					<p class="center"><?php echo $users; ?></p>
				</div>
				<div class="col-lg-3">
					<h1 class="border-box">Services</h1>
					<p class="center"><?php echo $services; ?></p>
				</div>
				<div class="col-lg-5">
					<h1 class="border-box">Applied Users</h1>
					<p class="center"><?php echo $appliedpeople; ?></p>
				</div>


			</div>
			<!--search form !-->
			<div class="row">
				
			<div class="col-lg-2"></div>
			<div class="col-lg-8">
			<h4 class="center">Search here any user</h4>
				<br>
			<form style="text-align:center" action =" " method="POST" class="form-inline">
			<i class="fa fa-search" aria-hidden="true"></i>
	  <input class="form-control form-control-sm ml-3 w-75" type="text" placeholder="Search" name="Name"   aria-label="Search">
	 
	  <input type="submit" class="btn btn-primary" value="search" name="search">

		</form>
			<?php
				echo "<div class='row'>";
				echo "<div class='col-lg-2'></div>";
				echo "<div class='col-lg-8'>";
				if(isset($_POST['search'])){ //check if form was submitted
					$input = $_POST['Name']; //get input text
					$message = " You entered: ".$input;
					echo $message;
					$host = "localhost";
$dbUsername = "root";
$dbPassword = "qwerty";
$dbname = "fyp";

//create connection
$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
if (mysqli_connect_error()) {
 die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
} else {
  $sql = "SELECT pic,email,level,name FROM `registration` where `email` = '$input'";
  $result = $conn->query($sql);
  
  if ($result->num_rows > 0){
  
  
  while($row = $result->fetch_assoc()) {
	$path=$row['pic'];
      
	$email=$row['email'];
      $level=$row["level"];
	  $Name=$row['name'];
	  $int_level = (int)$level;
	echo "<div class='card' style='width:300px; text-align:center'>";
	echo "<img class='card-img-top' src='images/$path' alt='$Name' style='width:100%'>";
	echo "<div class='card-body'>";
	
             
			  echo "<h5 class='card-title'>$Name " ;
			  echo "</h5>";
				echo "<h4 class='card-text'>";
			  
				for ($i=0;$i<$int_level;$i++){
					echo "<img src='images/star.png' height='80px' width='80px'/>";
				}
			  echo "</h4>";
			  echo "<a href='profile.php?id=$email' class='btn btn-primary'>See Profile</a>";
      
			  echo "</div>";
			  echo "</div>";
      
      
	  }
	}else{
		echo "<br>No result found!";
	}
    }
				  } else{
					  echo "Enter user email to find the id";
				  }
				echo "</div>";
				echo "</div>";

			?>
			</div>
			<div classa="col-lg-2"></div>

			</div>

		</div>
		</div>

    <script src="js1/jquery.min.js"></script>
    <script src="js1/popper.js"></script>
    <script src="js1/bootstrap.min.js"></script>
	<script src="js1/main.js"></script>
	<script>
		
		</script>
  </body>
</html>