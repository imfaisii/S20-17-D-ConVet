<?php
session_start();
$id2=$_SESSION['id'];
$servername = "localhost";
        $username = "username";
        $password = "qwerty";
        $dbname = "fyp";
        
        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
if(isset($_GET['submit_delete'])){
  $query=$_GET['imei_gsm'];
  $SELECT = "DELETE from appliedusers where appliedFor = '$query'";
  $result = $conn->query($SELECT);
}
?>
<!doctype html>
<html lang="en">

<head>
  <title>ConVet &mdash; Connecting People</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  
  <link href="https://fonts.googleapis.com/css?family=Muli:300,400,700,900" rel="stylesheet">
  <link rel="stylesheet" href="fonts/icomoon/style.css">

  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/jquery-ui.css">
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">

  <link rel="stylesheet" href="css/jquery.fancybox.min.css">

  <link rel="stylesheet" href="css/bootstrap-datepicker.css">

  <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

  <link rel="stylesheet" href="css/aos.css">
  <link href="css/jquery.mb.YTPlayer.min.css" media="all" rel="stylesheet" type="text/css">

  <link rel="stylesheet" href="css/style.css">



</head>
<style>
  .card {
  /* Add shadows to create the "card" effect */
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);

    
transition: 0.3s;
}

/* On mouse-over, add a deeper shadow */
.card:hover {
  box-shadow: 
0 8px 16px 0 rgba(0,0,0,0.2);
}

/* Add some padding inside the card container */
.container {

    
padding: 2px 16px;
}
th {
background-color: grey;
color: white;
}
tr {
  color:black;
}
tr:nth-child(even) {background-color: #f2f2f2}
</style>
<script>
  var $form = $('#payment-form');
$form.on('submit', payWithStripe);

/* If you're using Stripe for payments */
function payWithStripe(e) {
e.preventDefault();

/* Visual feedback */
$form.find('[type=submit]').html('Validating <i class="fa fa-spinner fa-pulse"></i>');

var PublishableKey = 'pk_test_b1qXXwATmiaA1VDJ1mOVVO1p'; // Replace with your API publishable key
Stripe.setPublishableKey(PublishableKey);

/* Create token */
var expiry = $form.find('[name=cardExpiry]').payment('cardExpiryVal');
var ccData = {
   number: $form.find('[name=cardNumber]').val().replace(/\s/g,''),
   cvc: $form.find('[name=cardCVC]').val(),
   exp_month: expiry.month, 
   exp_year: expiry.year
};

Stripe.card.createToken(ccData, function stripeResponseHandler(status, response) {
   if (response.error) {
       /* Visual feedback */
       $form.find('[type=submit]').html('Try again');
       /* Show Stripe errors on the form */
       $form.find('.payment-errors').text(response.error.message);
       $form.find('.payment-errors').closest('.row').show();
   } else {
       /* Visual feedback */
       $form.find('[type=submit]').html('Processing <i class="fa fa-spinner fa-pulse"></i>');
       /* Hide Stripe errors on the form */
       $form.find('.payment-errors').closest('.row').hide();
       $form.find('.payment-errors').text("");
       // response contains id and card, which contains additional card details            
       console.log(response.id);
       console.log(response.card);
       var token = response.id;
       // AJAX - you would send 'token' to your server here.
       $.post('/account/stripe_card_token', {
               token: token
           })
           // Assign handlers immediately after making the request,
           .done(function(data, textStatus, jqXHR) {
               $form.find('[type=submit]').html('Payment successful <i class="fa fa-check"></i>').prop('disabled', true);
           })
           .fail(function(jqXHR, textStatus, errorThrown) {
               $form.find('[type=submit]').html('There was a problem').removeClass('success').addClass('error');
               /* Show Stripe errors on the form */
               $form.find('.payment-errors').text('Try refreshing the page and trying again.');
               $form.find('.payment-errors').closest('.row').show();
           });
   }
});
}
/* Fancy restrictive input formatting via jQuery.payment library*/
$('input[name=cardNumber]').payment('formatCardNumber');
$('input[name=cardCVC]').payment('formatCardCVC');
$('input[name=cardExpiry').payment('formatCardExpiry');

/* Form validation using Stripe client-side validation helpers */
jQuery.validator.addMethod("cardNumber", function(value, element) {
return this.optional(element) || Stripe.card.validateCardNumber(value);
}, "Please specify a valid credit card number.");

jQuery.validator.addMethod("cardExpiry", function(value, element) {    
/* Parsing month/year uses jQuery.payment library */
value = $.payment.cardExpiryVal(value);
return this.optional(element) || Stripe.card.validateExpiry(value.month, value.year);
}, "Invalid expiration date.");

jQuery.validator.addMethod("cardCVC", function(value, element) {
return this.optional(element) || Stripe.card.validateCVC(value);
}, "Invalid CVC.");

validator = $form.validate({
rules: {
   cardNumber: {
       required: true,
       cardNumber: true            
   },
   cardExpiry: {
       required: true,
       cardExpiry: true
   },
   cardCVC: {
       required: true,
       cardCVC: true
   }
},
highlight: function(element) {
   $(element).closest('.form-control').removeClass('success').addClass('error');
},
unhighlight: function(element) {
   $(element).closest('.form-control').removeClass('error').addClass('success');
},
errorPlacement: function(error, element) {
   $(element).closest('.form-group').append(error);
}
});

paymentFormReady = function() {
if ($form.find('[name=cardNumber]').hasClass("success") &&
   $form.find('[name=cardExpiry]').hasClass("success") &&
   $form.find('[name=cardCVC]').val().length > 1) {
   return true;
} else {
   return false;
}
}

$form.find('[type=submit]').prop('disabled', true);
var readyInterval = setInterval(function() {
if (paymentFormReady()) {
   $form.find('[type=submit]').prop('disabled', false);
   clearInterval(readyInterval);
}
}, 250);
</script>
<style>
  input[type=radio] {
    width: 20px;
    height: 20px;
}
</style>
<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">

  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>


    <header class="site-navbar py-4 js-sticky-header site-navbar-target" role="banner">

      <div class="container-fluid">
        <div class="d-flex align-items-center">
          <div class="site-logo"><a href="index.html">News Feed<span>.</span> </a></div>
          <div class="ml-auto">
            <nav class="site-navigation position-relative text-right" role="navigation">
              <ul class="site-menu main-menu js-clone-nav mr-auto d-none d-lg-block">
                <li><a href="pages/home.php" class="nav-link">Home</a></li>
                <li><a href="#services-section" class="nav-link">Services</a></li>
                <li><a href="application_status.php" class="nav-link">Application Status</a></li>
                <li><a href="pages/login.html" class="nav-link">I am organization</a></li>
              </ul>
            </nav>
            <a href="#" class="d-inline-block d-lg-none site-menu-toggle js-menu-toggle float-right"><span class="icon-menu h3"></span></a>
          </div>

        </div>
      </div>

    </header>


    <div class="intro-section" id="home-section" style="background-color: #ccc;">

      <div class="container">

        <div class="row align-items-center">
          <div class="col-lg-12 mx-auto text-center" data-aos="fade-up">
            <h1 class="mb-3">Sevices Waiting for you !</h1>
            <p class="lead mx-auto desc mb-5">We hope you will be there !
            </p>
            <p class="text-center">
              <a href="#services-section" class="btn btn-outline-white py-3 px-5">View Now</a>
            </p>
          </div>
        </div>

      </div>
    </div>
</div>

    <div class="site-section" id="services-section">
      <div class="container">
        <div class="row justify-content-center text-center mb-5" data-aos="fade-up">
          <div class="col-md-8  section-heading">
            <h2 class="heading mb-3">Recreational Services</h2>
            
          </div>
        </div>
        <?php
        $servername = "localhost";
        $username = "username";
        $password = "qwerty";
        $dbname = "fyp";
        
        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        
        $sql = "SELECT * FROM appliedusers where joinedBy='$id2'";
        $result = $conn->query($sql);
        echo    "<div class='row'>
        <div class='container'><table border='2' class='table table-striped'>
        <tr>
        <th scope='col'>Applied For</th>
        <th scope='col'>Date</th>
        <th scope='col'>Service By</th>
        <th scope='col'>Status</th>
		  <th scope='col'>Check</th>
        </tr>";
        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
              echo "<tr>";
			  
              echo "<td>" . $row['appliedFor'] . "</td>";
              $temp=$row['appliedFor'];
              echo "<td>" . $row['date'] . "</td>";
              echo "<td>" . $row['serviceBy'] . "</td>";
			  $appliedfor=$row['serviceBy'];
			  $id3=$row['id'];
              echo "<td>
              <form action='' method='GET'>
              <input type='hidden' id='custId' name='imei_gsm' value='$temp'/>
              <input class='btn btn-primary' type='submit' name='submit_delete' value='Will not Be there!' />
              </form>
			  </td>
			  <td>
			  <form action='service_check.php' method='POST'>
              ";
			  ?>
			  <!-- Button trigger modal -->
	<button type="button" class="btn btn-success" data-toggle="modal" data-target="#exampleModal">
  View This Service
</button>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"><?php echo "<h1>";echo $row['appliedFor']; echo"</h1>"; ?> </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
			<?php echo "<h4>"; echo "Service BY :"; echo $appliedfor; echo "<br>";
			echo "Date:"; echo $row['date']; echo "<br>";
			echo "</h4>";
			echo "<h5> People Who Applied For it </h5>";
			
			 $sql1 = "SELECT joinedBy FROM appliedusers where id='$id3'";
        $result1 = $conn->query($sql1);
		if ($result1->num_rows > 0) {
            // output data of each row
            while($row1 = $result1->fetch_assoc()) {
				$mail=$row1['joinedBy'];
				echo "<a href='profile_view.php?id=$mail'>";
				echo $mail; echo "<br>";
				echo "</a>";
		}
		}else{
			echo "Query n kuch dioa e nhe ";
		}
		?>	
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>
			<?php
              echo "</form>
              </td>";
              echo "</tr>";
              }
              
              echo "</table></div></div>";
              
                }
        else {
            echo " No services Joined Yet !";
        }
        
        $conn->close();
        ?></div></div></div></div>

<!-- Modal -->


	

    <footer class="pt-5 pb-4" id="contact">
			<div class="container">
				<div class="row">
					<div class="col-lg-6">
						<h5 class="mb-8 font-weight-bold">ABOUT US</h5><br>
						<ul class="f-address">
							<li>
								<div class="row">
									<div class="col-1"><i class="fas fa-map-marker"></i></div>
                
							</li>
							<li>
								<div class="row">
									<div class="col-1"><i class="far fa-envelope"></i></div>
									<div class="col-10">
										<h6 class="font-weight-bold mb-0">Have any questions?</h6>
										<p><a href="pages/complain.html">Support@universalmart.com</a></p>
									</div>
								</div>
							</li>
							<li>
								<div class="row">
									<div class="col-1"></i></div>
									<div class="col-10">
										<h6 class="font-weight-bold mb-0">Phone No:</h6>
										<p><a href="#">+92 (0) 51-33-33211-33312</a></p>
									</div>
								</div>
              </li>
              
						</ul>
					</div>
					<div class="col-lg-3 col-md-6 col-sm-6 mt-2 mb-4">
						<ul class="f-address">
						</ul>
					</div>
					
          </div>
          
				</div>
			</div>
		</footer>
		<!-- Copyright -->
		<section class="copyright">
			<div class="container">
				<div class="row">
					<div class="col-md-12 ">
						<div class="text-center text-black" style="padding-bottom: 50px;">
							&copy; <strong>2019 Universal Mart. All Rights Reserved.</strong>
						</div>
					</div>
				</div>
			</div>
		</section>
    
  <!-- .site-wrap -->

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.fancybox.min.js"></script>
  <script src="js/jquery.sticky.js"></script>
  <script src="js/jquery.mb.YTPlayer.min.js"></script>




  <script src="js/main.js"></script>

</body>
</html>