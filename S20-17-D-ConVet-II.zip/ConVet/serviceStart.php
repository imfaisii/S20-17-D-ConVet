<?php
					$serviceName = $_POST['serviceName']; //get input text
					$message = " You entered serviceName : ".$serviceName;
					$serviceDescription = $_POST['serviceDescription']; //get input text
					$message = " You entered serviceDescription : ".$serviceDescription;
					echo $message;
					
$target_dir = "../images/";
$file_name=basename($_FILES["fileToUpload"]["name"]);
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
  $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
  if($check !== false) {
    $uploadOk = 1;
  } else {
    $uploadOk = 0;
  }
}



// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
  echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
  $uploadOk = 0;
}

// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
  echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
  if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
					$host = "localhost";
$dbUsername = "root";
$dbPassword = "qwerty";
$dbname = "fyp";

//create connection
$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
if (mysqli_connect_error()) {
 die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
} else {
  $sql = "INSERT INTO `adminservice`(`name`, `description`, `image`) VALUES ('$serviceName','$serviceDescription','$file_name')";
  mysqli_query($conn, $INSERT);
}
  }
}

  ?>