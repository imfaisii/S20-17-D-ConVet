<?php
session_start();
$id2=$_SESSION['id'];?>
<!doctype html>
<html lang="en">

<head>
  <title>ConVet &mdash; Connecting People</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  
  <link href="https://fonts.googleapis.com/css?family=Muli:300,400,700,900" rel="stylesheet">
  <link rel="stylesheet" href="fonts/icomoon/style.css">

  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/jquery-ui.css">
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">

  <link rel="stylesheet" href="css/jquery.fancybox.min.css">

  <link rel="stylesheet" href="css/bootstrap-datepicker.css">

  <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

  <link rel="stylesheet" href="css/aos.css">
  <link href="css/jquery.mb.YTPlayer.min.css" media="all" rel="stylesheet" type="text/css">

  <link rel="stylesheet" href="css/style.css">



</head>
<style>
  .card {
  /* Add shadows to create the "card" effect */
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);

    
transition: 0.3s;
}

/* On mouse-over, add a deeper shadow */
.card:hover {
  box-shadow: 
0 8px 16px 0 rgba(0,0,0,0.2);
}

/* Add some padding inside the card container */
.container {

    
padding: 2px 16px;
} 
  table {
border-collapse: collapse;
width: 100%;
color: #C74327;
font-family: monospace;
font-size: 25px;
text-align: left;
}
th {
background-color: #C74327;
color: white;
}
tr:nth-child(even) {background-color: #f2f2f2}

/*div {
    border-width:5px;  
    border-style:double;
}*/
</style>
<script>
  var $form = $('#payment-form');
$form.on('submit', payWithStripe);

/* If you're using Stripe for payments */
function payWithStripe(e) {
e.preventDefault();

/* Visual feedback */
$form.find('[type=submit]').html('Validating <i class="fa fa-spinner fa-pulse"></i>');

var PublishableKey = 'pk_test_b1qXXwATmiaA1VDJ1mOVVO1p'; // Replace with your API publishable key
Stripe.setPublishableKey(PublishableKey);

/* Create token */
var expiry = $form.find('[name=cardExpiry]').payment('cardExpiryVal');
var ccData = {
   number: $form.find('[name=cardNumber]').val().replace(/\s/g,''),
   cvc: $form.find('[name=cardCVC]').val(),
   exp_month: expiry.month, 
   exp_year: expiry.year
};

Stripe.card.createToken(ccData, function stripeResponseHandler(status, response) {
   if (response.error) {
       /* Visual feedback */
       $form.find('[type=submit]').html('Try again');
       /* Show Stripe errors on the form */
       $form.find('.payment-errors').text(response.error.message);
       $form.find('.payment-errors').closest('.row').show();
   } else {
       /* Visual feedback */
       $form.find('[type=submit]').html('Processing <i class="fa fa-spinner fa-pulse"></i>');
       /* Hide Stripe errors on the form */
       $form.find('.payment-errors').closest('.row').hide();
       $form.find('.payment-errors').text("");
       // response contains id and card, which contains additional card details            
       console.log(response.id);
       console.log(response.card);
       var token = response.id;
       // AJAX - you would send 'token' to your server here.
       $.post('/account/stripe_card_token', {
               token: token
           })
           // Assign handlers immediately after making the request,
           .done(function(data, textStatus, jqXHR) {
               $form.find('[type=submit]').html('Payment successful <i class="fa fa-check"></i>').prop('disabled', true);
           })
           .fail(function(jqXHR, textStatus, errorThrown) {
               $form.find('[type=submit]').html('There was a problem').removeClass('success').addClass('error');
               /* Show Stripe errors on the form */
               $form.find('.payment-errors').text('Try refreshing the page and trying again.');
               $form.find('.payment-errors').closest('.row').show();
           });
   }
});
}
/* Fancy restrictive input formatting via jQuery.payment library*/
$('input[name=cardNumber]').payment('formatCardNumber');
$('input[name=cardCVC]').payment('formatCardCVC');
$('input[name=cardExpiry').payment('formatCardExpiry');

/* Form validation using Stripe client-side validation helpers */
jQuery.validator.addMethod("cardNumber", function(value, element) {
return this.optional(element) || Stripe.card.validateCardNumber(value);
}, "Please specify a valid credit card number.");

jQuery.validator.addMethod("cardExpiry", function(value, element) {    
/* Parsing month/year uses jQuery.payment library */
value = $.payment.cardExpiryVal(value);
return this.optional(element) || Stripe.card.validateExpiry(value.month, value.year);
}, "Invalid expiration date.");

jQuery.validator.addMethod("cardCVC", function(value, element) {
return this.optional(element) || Stripe.card.validateCVC(value);
}, "Invalid CVC.");

validator = $form.validate({
rules: {
   cardNumber: {
       required: true,
       cardNumber: true            
   },
   cardExpiry: {
       required: true,
       cardExpiry: true
   },
   cardCVC: {
       required: true,
       cardCVC: true
   }
},
highlight: function(element) {
   $(element).closest('.form-control').removeClass('success').addClass('error');
},
unhighlight: function(element) {
   $(element).closest('.form-control').removeClass('error').addClass('success');
},
errorPlacement: function(error, element) {
   $(element).closest('.form-group').append(error);
}
});

paymentFormReady = function() {
if ($form.find('[name=cardNumber]').hasClass("success") &&
   $form.find('[name=cardExpiry]').hasClass("success") &&
   $form.find('[name=cardCVC]').val().length > 1) {
   return true;
} else {
   return false;
}
}

$form.find('[type=submit]').prop('disabled', true);
var readyInterval = setInterval(function() {
if (paymentFormReady()) {
   $form.find('[type=submit]').prop('disabled', false);
   clearInterval(readyInterval);
}
}, 250);
</script>
<style>
  input[type=radio] {
    width: 20px;
    height: 20px;
}
</style>
<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">

  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>


    <header class="site-navbar py-4 js-sticky-header site-navbar-target" role="banner">

      <div class="container-fluid">
        <div class="d-flex align-items-center">
          <div class="site-logo"><a href="index.html">News Feed<span>.</span> </a></div>
          <div class="ml-auto">
            <nav class="site-navigation position-relative text-right" role="navigation">
              <ul class="site-menu main-menu js-clone-nav mr-auto d-none d-lg-block">
                <li><a href="pages/home.php" class="nav-link">Home</a></li>
                <li><a href="joined_services.php?id1=<?php echo $id2 ?>" class="nav-link">Joined Services</a></li>
				<li><a href="application_status.php" class="nav-link">Application Status</a></li>
                <li><a href="profile.php" class="nav-link">Profile</a></li>
                <li><a href="welcome.html" class="nav-link">Logout</a></li>
              </ul>
            </nav>
            <a href="#" class="d-inline-block d-lg-none site-menu-toggle js-menu-toggle float-right"><span class="icon-menu h3"></span></a>
          </div>

        </div>
      </div>

    </header>


    <div class="intro-section" id="home-section" style="background-color: #ccc;">

      <div class="container">

        <div class="row align-items-center">
          <div class="col-lg-12 mx-auto text-center" data-aos="fade-up">
            <h1 class="mb-3">Your News Feed</h1>
            <p class="lead mx-auto desc mb-5">Here you will find all the active/deactivated services. Enjoy ! 
            </p>
            <p class="text-center">
              <a href="#services-section" class="btn btn-outline-white py-3 px-5">Get Started</a>
            </p>
          </div>
        </div>

      </div>
    </div>
</div>

    <div class="site-section" id="services-section">
      <div class="container">
        <div class="row justify-content-center text-center mb-5" data-aos="fade-up">
          <div class="col-md-8  section-heading">
            <h2 class="heading mb-3">Recreational Services</h2>
            <h5><button type="button" class="btn btn-info" onclick='foryou()'>For You</button>
            <button type="button" class="btn btn-success" onclick='following()'>Following</button>
            </h5>
            
          </div>
        </div>
		<div class="row">
		
		<div class="col-lg-6" id="content">
        <?php
        $servername = "localhost";
        $username = "username";
        $password = "qwerty";
        $dbname = "fyp";
        
        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
		
        
        $sql = "SELECT id,serviceName, Date, startedBy,imagePath FROM services";
        $result = $conn->query($sql);
        echo "<div class='card'>";
        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
              $id=$row['id'];
              $path=$row['imagePath'];
              echo "<img src='$path' height='300px'/>";
              echo "<div class='card-body'>";
              echo "<h5 class='card-title'>";
              $serviceName=$row['serviceName'];
              echo $row['serviceName'];
              echo "</h5>";
              echo "<p class='card-text'>Will be done on : ";
              $date1=$row['Date'];
              echo  $row['Date'];
              echo "<br>Was Started By : ";
              $serviceBy=$row['startedBy'];
              echo  $row['startedBy'] ;
              echo "</p>";
              
              $INSERT1="SELECT `joinedBy` FROM `appliedusers` WHERE  `joinedBy`='$id2' AND `id`='$id'";
              $result1 = $conn->query($INSERT1);
           if ($result1->num_rows > 0){
            echo "<form action='unapply.php?serviceName=$serviceName&date=$date1&serviceBy=$serviceBy&id=$id' method='POST'>";
              echo "<button type='submit' class='btn btn-success' data-toggle='modal' data-target='#exampleModalCenter'>";
              echo "I don't wanna Go";
              echo "</button></form>";
            }else {
              echo "<form action='apply.php?serviceName=$serviceName&date=$date1&serviceBy=$serviceBy&id=$id' method='POST'>";
              echo "<button type='submit' class='btn btn-primary' data-toggle='modal' data-target='#exampleModalCenter'>";
              echo "Apply for This service";
              echo "</button></form>";
            }
              echo "</div>";
              }
              
              echo "</div>";
              
                }
        else {
            echo " No services Started Yet !";
        }
        
        //$conn->close();
        ?></div>
		
		<div class="col-lg-3" >
		<h3 class="heading mb-3">
		<strong>
		Paid Jobs You may be interested in
		 
		</strong>
		</h3>
		
		<?php
		
		$sql="select category from registration where email='$id2' ";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
		$skills=$row["category"];
		}
} else {
  echo "0 results";
}
		$counter=0;
		$sql = "select jobPosition,salary,jobDuration,category,id from job where category='$skills' ";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
				if($counter<=100)
				{
				if($row['category']==$skills )
				{
					 $idd=$row['id'];
					$sql1 = "select imagePath from services where id='$idd' ";
					$result1 = $conn->query($sql1);
					  while($row1 = $result1->fetch_assoc()) {
						  $path=$row1['imagePath'];
						  $path=substr($path,7);
					  }
			  //$path=$row['pic'];
			  echo "<div class='row'  ><div class='col-lg-2' ></div>";
			  $redirectName=$row['jobPosition'];
              echo "<a href='#'><img src='images/$path' style='border-width:5px; border-style:double; ' height='100px'/></a>";
              echo "<div class='card-body'>";
              echo "<h5 class='card-title'>";
              $serviceName=$row['salary'];
			  ?>
			  <?php
			  $sql111 = "SELECT startedBy FROM services where id='$idd'";
        $result111 = $conn->query($sql111);
		if ($result111->num_rows > 0) {
            // output data of each row
            while($row111 = $result111->fetch_assoc()) {
				$jobby=$row111['startedBy'];
				
			}
		}
		?>
			  <?php
              echo $row['jobPosition'];
			  echo "<h6> Job by:$jobby </h6>";
			  echo "</a>";
              echo "</h5>";
              echo  $row['salary']." RS" ;
			  echo "<br>";
			  echo "Duration : ".$row['jobDuration']," days";
              echo "</p>";
			  $SELECT44 = "SELECT `id` FROM `appliedjob` where `id`='$idd' && `applier`='$id2' ";   //to check pehly s tu dost nhe
			  $result44 = $conn->query($SELECT44);
              if ($result44->num_rows > 0){
				 // echo '<script>alert("aya alert")</script>'; 
              while($row4 = $result44->fetch_assoc()) {
              $name1=$row4['id'];
			  // echo '<script>alert(';
			   //echo $name1;
			   //echo ')</script>'; 
			  
              }
              if ($name1==$idd){  
			  echo "<form action='remove_job.php?friend=$name1' method='POST'>";
              echo "<button type='submit' class='btn btn-success'  data-toggle='modal' data-target='#exampleModalCenter'>";
			  echo "Remove Application";
			  echo "</button></form>";
              }	  
			  }
			  else
			  {
			  echo "<form action='add_job.php?friend=$idd' method='POST'>";
			  echo "<button type='submit' class='btn btn-danger' style='color:white;' data-toggle='modal' data-target='#exampleModalCenter'>";
              echo "Apply For this job";
			  echo "</button></form>";
			  }
			  
              echo "</div>";
			  echo "</div>";
              
			}
				}
			$counter++;
			
                }?>
				<!-- view job application Card -->
					<!--<button type="button" class="btn btn-warning" data-toggle="modal" data-target="#exampleModal">
  View This Job
</button>
-->
<!-- Modal -->
		<?php
		$sql11 = "SELECT * FROM job where id='$idd'";
        $result11 = $conn->query($sql11);
		if ($result11->num_rows > 0) {
            // output data of each row
            while($row11 = $result11->fetch_assoc()) {
				$jobdesc=$row11['jobDescription'];
				$jobpos=$row11['jobPosition'];
				$jobsal=$row11['salary'];
			}
		}
		
		?>
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"><?php echo "<h1>";echo $jobpos; echo"</h1>"; ?> </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
			<?php echo "<h6>"; echo "<strong>Description </strong> :"; echo $jobdesc; echo "<br>";
			echo "Salary:"; echo $jobsal; echo "<br>";
			echo "</h6>";
			echo "<h5> People Who Applied For it </h5>";
			
			 $sql1 = "SELECT applier FROM appliedjob where id='$idd'";
        $result1 = $conn->query($sql1);
		if ($result1->num_rows > 0) {
            // output data of each row
            while($row1 = $result1->fetch_assoc()) {
				$mail=$row1['applier'];
				echo "<a href='profile_view.php?id=$mail'>";
				echo $mail; echo "<br>";
				echo "</a>";
		}
		}else{
			echo "Query n kuch dioa e nhe ";
		}
		?>	
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>
		
		<?php }
        else {
            echo " Nothing to show :( !";
        }?>
		</div>
		<!-- PAID JOBS-->
		
		<div class="col-lg-3" style="border-style:double;height:1050px" >
		<h3 class="heading mb-3">
		<strong>
		People you may be interested in
		</strong>
		</h3>
		<?php
		
		$sql="select category from registration where email='$id2'";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
		$skills=$row["category"];
		}
} else {
  echo "0 results";
}
		$counter=0;
		$sql = "SELECT name,regType,pic,skills,email,category FROM registration WHERE category='$skills'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
				if($counter<=3)
				{
				if($row['category']==$skills && $row['email']!==$id2)
				{
			  $path=$row['pic'];
			  $mail=$row['email'];
			  echo "<div class='row' ><div class='col-lg-2'></div>";
			  $redirectName=$row['name'];
              echo "<a href='profile_view.php?id=$mail'><img src='images/$path' style='border-radius: 50%; ' height='100px'/></a>";
              echo "<div class='card-body'>";
              echo "<h5 class='card-title'>";
              $serviceName=$row['email'];
			  echo "<a href='profile_view.php?id=$mail'>";
              echo $row['name'];
			  echo "</a>";
              echo "</h5>";
              echo  $row['regType'] ;
			  echo "<br>";
			  echo "Profession Type : ".$row['skills'];
              echo "</p>";
			  $SELECT4 = "SELECT friend FROM `friend` where `friend`='$serviceName' && `name`='$id2' ";   //to check pehly s tu dost nhe
			  $result4 = $conn->query($SELECT4);
              if ($result4->num_rows > 0){
              while($row = $result4->fetch_assoc()) {
              $name=$row['friend'];
              }
              if ($name==$serviceName){  
			  echo "<form action='remove_friend.php?friend=$serviceName' method='POST'>";
              echo "<button type='submit' class='btn btn-success'  data-toggle='modal' data-target='#exampleModalCenter'>";
			  echo "Remove Friend";
			  echo "</button></form>";
              }	  
			  }
			  else
			  {
			  echo "<form action='add_friend.php?friend=$serviceName' method='POST'>";
			  echo "<button type='submit' class='btn btn-danger' style='color:white;' data-toggle='modal' data-target='#exampleModalCenter'>";
              echo "Add as Friend";
			  echo "</button></form>";
			  }
			  
              echo "</div>";
			  echo "</div>";
              
			}
				}
			$counter++;
                }
		}
        else {
            echo " Nothing to show :( !";
        }?>
		</div>
		<!-- paid jobs end -->
		</div></div></div></div>

<!-- Modal -->

    <footer class="pt-5 pb-4" id="contact">
			<div class="container">
				<div class="row">
					<div class="col-lg-6">
						<h5 class="mb-8 font-weight-bold">ABOUT US</h5><br>
						<ul class="f-address">
							<li>
								<div class="row">
									<div class="col-1"><i class="fas fa-map-marker"></i></div>
                
							</li>
							<li>
								<div class="row">
									<div class="col-1"><i class="far fa-envelope"></i></div>
									<div class="col-10">
										<h6 class="font-weight-bold mb-0">Have any questions?</h6>
										<p><a href="pages/complain.html">Support@ConVet.com</a></p>
									</div>
								</div>
							</li>
							<li>
								<div class="row">
									<div class="col-1"></i></div>
									<div class="col-10">
										<h6 class="font-weight-bold mb-0">Phone No:</h6>
										<p><a href="#">+92 (0) 51-33-33211-33312</a></p>
									</div>
								</div>
              </li>
              
						</ul>
					</div>
					<div class="col-lg-3 col-md-6 col-sm-6 mt-2 mb-4">
						<ul class="f-address">
						</ul>
					</div>
					
          </div>
          
				</div>
			</div>
		</footer>
		<!-- Copyright -->
		<section class="copyright">
			<div class="container">
				<div class="row">
					<div class="col-md-12 ">
						<div class="text-center text-black" style="padding-bottom: 50px;">
							&copy; <strong>2019 All Rights Reserved.</strong>
						</div>
					</div>
				</div>
			</div>
		</section>
    
  <!-- .site-wrap -->

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.fancybox.min.js"></script>
  <script src="js/jquery.sticky.js"></script>
  <script src="js/jquery.mb.YTPlayer.min.js"></script>

        <script>
     function  foryou(){
        
        document.getElementById("content").innerHTML="<?php 
          
          $servername = "localhost";
        $username = "username";
        $password = "qwerty";
        $dbname = "fyp";
        
        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
		
        
        $sql = "SELECT id,serviceName, Date, startedBy,imagePath FROM services";
        $result = $conn->query($sql);
        echo "<div class='card'>";
        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
              $id=$row['id'];
              $path=$row['imagePath'];
              echo "<img src='$path' height='300px'/>";
              echo "<div class='card-body'>";
              echo "<h5 class='card-title'>";
              $serviceName=$row['serviceName'];
              echo $row['serviceName'];
              echo "</h5>";
              echo "<p class='card-text'>Will be done on : ";
              $date1=$row['Date'];
              echo  $row['Date'];
              echo "<br>Was Started By : ";
              $serviceBy=$row['startedBy'];
              echo  $row['startedBy'] ;
              echo "</p>";
              
              $INSERT1="SELECT `joinedBy` FROM `appliedusers` WHERE  `joinedBy`='$id2' AND `id`='$id'";
              $result1 = $conn->query($INSERT1);
           if ($result1->num_rows > 0){
            echo "<form action='unapply.php?serviceName=$serviceName&date=$date1&serviceBy=$serviceBy&id=$id' method='POST'>";
              echo "<button type='submit' class='btn btn-success' data-toggle='modal' data-target='#exampleModalCenter'>";
              echo "I don't wanna Go";
              echo "</button></form>";
            }else {
              echo "<form action='apply.php?serviceName=$serviceName&date=$date1&serviceBy=$serviceBy&id=$id' method='POST'>";
              echo "<button type='submit' class='btn btn-primary' data-toggle='modal' data-target='#exampleModalCenter'>";
              echo "Apply for This service";
              echo "</button></form>";
            }
              echo "</div>";
              }
              
              echo "</div>";
              
                }
        else {
            echo " No services Started Yet !";
        }
        
        
          
          
          ?>"

      }
      function  following(){
        document.getElementById("content").innerHTML="<?php 
          
          $servername = "localhost";
        $username = "username";
        $password = "qwerty";
        $dbname = "fyp";
        
        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
		
        
        $sql = "SELECT id,serviceName, Date, startedBy,imagePath FROM services WHERE `startedBy`=(SELECT `friend` FROM friend WHERE `name`='$id2')";
        $result = $conn->query($sql);
        echo "<div class='card'>";
        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
              $id=$row['id'];
              $path=$row['imagePath'];
              echo "<img src='$path' height='300px'/>";
              echo "<div class='card-body'>";
              echo "<h5 class='card-title'>";
              $serviceName=$row['serviceName'];
              echo $row['serviceName'];
              echo "</h5>";
              echo "<p class='card-text'>Will be done on : ";
              $date1=$row['Date'];
              echo  $row['Date'];
              echo "<br>Was Started By : ";
              $serviceBy=$row['startedBy'];
              echo  $row['startedBy'] ;
              echo "</p>";
              
              $INSERT1="SELECT `joinedBy` FROM `appliedusers` WHERE  `joinedBy`='$id2' AND `id`='$id'";
              $result1 = $conn->query($INSERT1);
           if ($result1->num_rows > 0){
            echo "<form action='unapply.php?serviceName=$serviceName&date=$date1&serviceBy=$serviceBy&id=$id' method='POST'>";
              echo "<button type='submit' class='btn btn-success' data-toggle='modal' data-target='#exampleModalCenter'>";
              echo "I don't wanna Go";
              echo "</button></form>";
            }else {
              echo "<form action='apply.php?serviceName=$serviceName&date=$date1&serviceBy=$serviceBy&id=$id' method='POST'>";
              echo "<button type='submit' class='btn btn-primary' data-toggle='modal' data-target='#exampleModalCenter'>";
              echo "Apply for This service";
              echo "</button></form>";
            }
              echo "</div>";
              }
              
              echo "</div>";
              
                }
        else {
            echo " Your friends Have started nothing till now !";
        }
        
        
          
          
          ?>"
      }


        </script>


  <script src="js/main.js"></script>

</body>
</html>