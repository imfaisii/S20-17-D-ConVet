<?php
session_start();
$id=$_SESSION['id'];        // the one jiska friend hoga
if (isset($_GET['id'])){



$id2=$_GET['id'];      //jiny friend banana
}
  

?>
<!doctype html>
<html lang="en">
  <head>
     <style>
        .loader1 {
  border: 16px solid #f3f3f3;
  border-radius: 50%;
  border-top: 16px solid #3498db;
  width: 120px;
  height: 120px;
  -webkit-animation: spin 2s linear infinite; /* Safari */
  animation: spin 2s linear infinite;
}
.center {
  margin: auto;
  width: 60%;
  border: 3px solid #73AD21;
  padding: 10px;
}
/* Safari */
@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
* {
  margin:0px;
  padding:0px;
  box-sizing:border-box;
}
.loader {
  position:absolute;
  top:65%;
  left:46%;
  transform:translate(-50%,-50%);
  width:130px;
}
.loader .pair {
  position:absolute;
  width:80px;
  height:30px;
}
.loader .pair .dot {
  position:absolute;
  width:30px;
  height:30px;
  background:#444;
  border-radius:50%;
}
.loader .pair .dot-2 {
  right:0px;
}
.loader .pair-2 {
  left:50px;
}
.loader .pair-1 {
  animation:spin 1000ms ease-in-out infinite;
}
.loader .pair-2 {
  animation:spin 1000ms ease-in-out infinite reverse;
}
.loader .pair-1 .dot-1 {
  opacity:0;
  animation:hide 1000ms ease-in-out infinite reverse;
}
.loader .pair-2 .dot-2 {
  opacity:0;
  animation:hide 1000ms ease-in-out infinite;
}
@keyframes hide {
  0%,49% {
    opacity:0;
  }
  50%,100% {
    opacity:1;
  }
}
@keyframes spin {
  0% {
    transform:rotate(0deg);
  }
  50%,100% {
    transform:rotate(180deg);
  }
}
        </style>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>
    <br><br><br><br><br>
  <div class="row">
    <div class="col-lg-4"></div>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <img src="images/PngItem_5157584.png" height="300px" width="300px">
</div>
<br>
  <!--  
    <div class="loader">
        <div class="pair pair-1">
          <div class="dot dot-1"></div>
          <div class="dot dot-2"></div>
        </div>
        <div class="pair pair-2">
          <div class="dot dot-1"></div>
          <div class="dot dot-2"></div>
        </div>
      </div>
    !-->
      <br><br><br><br><br><br>
    <label style="font-size: 20px; display: inline; padding-left: 30%;color:grey;font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;font-style: italic;">
    Yeh nhe ho sakta bhai!!!  .....</label>
      <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>
<?php

    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "qwerty";
    $dbname = "fyp";
    //create connection
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    if (mysqli_connect_error()) {
     die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    } else {

     
        $SELECT1 = "DELETE FROM `friend` WHERE `friend`='$id2' && `name`='$id'";
        $result1 = $conn->query($SELECT1);
        if (!$result1) {
            trigger_error('Invalid query: ' . $conn->error);
            header("refresh:10,url=search.php? id=$id");
        }else{
        header("refresh:0,url=search.php? id=$id");
        }
        
    

$conn->close();
    }

?>