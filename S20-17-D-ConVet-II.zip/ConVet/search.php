<?php
session_start();
if (isset($_GET['id1'])){



$id2=$_GET['id1'];
}else
{
  $id2=$_SESSION['id'];
}
$host = "localhost";
$dbUsername = "root";
$dbPassword = "YES";
$dbname = "fyp";
$counter=0;
  ?> 
<!DOCTYPE html>
<html lang="en">

<head>
  <title>ConVet &mdash; Connecting People</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  
  <link href="https://fonts.googleapis.com/css?family=Muli:300,400,700,900" rel="stylesheet">
  <link rel="stylesheet" href="fonts/icomoon/style.css">

  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/jquery-ui.css">
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">

  <link rel="stylesheet" href="css/jquery.fancybox.min.css">

  <link rel="stylesheet" href="css/bootstrap-datepicker.css">

  <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

  <link rel="stylesheet" href="css/aos.css">
  <link href="css/jquery.mb.YTPlayer.min.css" media="all" rel="stylesheet" type="text/css">

  <link rel="stylesheet" href="css/style.css">
<style>
* {
	border: 0;
	box-sizing: border-box;
	margin: 0;
	padding: 0;
}
.card {display:inline-block;}

:root {
	font-size: calc(16px + (24 - 16)*(100vw - 320px)/(1920 - 320));
}
button, input {
	font: 1em Hind, sans-serif;
	line-height: 1.5em;
}
input {
	color: #171717;
}
.search-bar {
	display: flex;
}
body {
	background: #f1f1f1;
	height: 100vh;
}
.search-bar input,
.search-btn, 
.search-btn:before, 
.search-btn:after {
	transition: all 0.25s ease-out;
}
.search-bar input,
.search-btn {
	width: 3em;
	height: 3em;
}
.search-bar input:invalid:not(:focus),
.search-btn {
	cursor: pointer;
}
.search-bar,
.search-bar input:focus,
.search-bar input:valid  {
	width: 100%;
}
.search-bar input:focus,
.search-bar input:not(:focus) + .search-btn:focus {
	outline: transparent;
}
.search-bar {
	margin: auto;
	padding: 1.5em;
	justify-content: center;
	max-width: 30em;
}
.search-bar input {
	background: transparent;
	border-radius: 1.5em;
	box-shadow: 0 0 0 0.4em white inset;
	padding: 0.75em;
	transform: translate(0.5em,0.5em) scale(0.5);
	transform-origin: 100% 0;
	-webkit-appearance: none;
	-moz-appearance: none;
	appearance: none;
}
.search-bar input::-webkit-search-decoration {
	-webkit-appearance: none;
}
.search-bar input:focus,
.search-bar input:valid {
	background: #fff;
	border-radius: 0.375em 0 0 0.375em;
	box-shadow: 0 0 0 0.1em #d9d9d9 inset;
	transform: scale(1);
}
.search-btn {
	background: white;
	border-radius: 0 0.75em 0.75em 0 / 0 1.5em 1.5em 0;
	padding: 0.75em;
	position: relative;
	transform: translate(0.25em,0.25em) rotate(45deg) scale(0.25,0.125);
	transform-origin: 0 50%;
}
.search-btn:before, 
.search-btn:after {
	content: "";
	display: block;
	opacity: 0;
	position: absolute;
}
.search-btn:before {
	border-radius: 50%;
	box-shadow: 0 0 0 0.2em #f1f1f1 inset;
	top: 0.75em;
	left: 0.75em;
	width: 1.2em;
	height: 1.2em;
}
.search-btn:after {
	background: #f1f1f1;
	border-radius: 0 0.25em 0.25em 0;
	top: 51%;
	left: 51%;
	width: 0.75em;
	height: 0.25em;
	transform: translate(0.2em,0) rotate(45deg);
	transform-origin: 0 50%;
}
.search-btn span {
	display: inline-block;
	overflow: hidden;
	width: 1px;
	height: 1px;
}

/* Active state */
.search-bar input:focus + .search-btn,
.search-bar input:valid + .search-btn {
	background: #2762f3;
	border-radius: 0 0.375em 0.375em 0;
	transform: scale(1);
}
.search-bar input:focus + .search-btn:before, 
.search-bar input:focus + .search-btn:after,
.search-bar input:valid + .search-btn:before, 
.search-bar input:valid + .search-btn:after {
	opacity: 1;
}
.search-bar input:focus + .search-btn:hover,
.search-bar input:valid + .search-btn:hover,
.search-bar input:valid:not(:focus) + .search-btn:focus {
	background: #0c48db;
}
.search-bar input:focus + .search-btn:active,
.search-bar input:valid + .search-btn:active {
	transform: translateY(1px);
}

@media screen and (prefers-color-scheme: dark) {
	body, input {
		color: #f1f1f1;
	}
	body {
		background: #171717;
	}
	.search-bar input {
		box-shadow: 0 0 0 0.4em #f1f1f1 inset;
	}
	.search-bar input:focus,
	.search-bar input:valid {
		background: #3d3d3d;
		box-shadow: 0 0 0 0.1em #3d3d3d inset;
	}
	.search-btn {
		background: #f1f1f1;
	}
}
</style>


</head>
<script>
  var $form = $('#payment-form');
$form.on('submit', payWithStripe);

/* If you're using Stripe for payments */
function payWithStripe(e) {
e.preventDefault();

/* Visual feedback */
$form.find('[type=submit]').html('Validating <i class="fa fa-spinner fa-pulse"></i>');

var PublishableKey = 'pk_test_b1qXXwATmiaA1VDJ1mOVVO1p'; // Replace with your API publishable key
Stripe.setPublishableKey(PublishableKey);

/* Create token */
var expiry = $form.find('[name=cardExpiry]').payment('cardExpiryVal');
var ccData = {
   number: $form.find('[name=cardNumber]').val().replace(/\s/g,''),
   cvc: $form.find('[name=cardCVC]').val(),
   exp_month: expiry.month, 
   exp_year: expiry.year
};

Stripe.card.createToken(ccData, function stripeResponseHandler(status, response) {
   if (response.error) {
       /* Visual feedback */
       $form.find('[type=submit]').html('Try again');
       /* Show Stripe errors on the form */
       $form.find('.payment-errors').text(response.error.message);
       $form.find('.payment-errors').closest('.row').show();
   } else {
       /* Visual feedback */
       $form.find('[type=submit]').html('Processing <i class="fa fa-spinner fa-pulse"></i>');
       /* Hide Stripe errors on the form */
       $form.find('.payment-errors').closest('.row').hide();
       $form.find('.payment-errors').text("");
       // response contains id and card, which contains additional card details            
       console.log(response.id);
       console.log(response.card);
       var token = response.id;
       // AJAX - you would send 'token' to your server here.
       $.post('/account/stripe_card_token', {
               token: token
           })
           // Assign handlers immediately after making the request,
           .done(function(data, textStatus, jqXHR) {
               $form.find('[type=submit]').html('Payment successful <i class="fa fa-check"></i>').prop('disabled', true);
           })
           .fail(function(jqXHR, textStatus, errorThrown) {
               $form.find('[type=submit]').html('There was a problem').removeClass('success').addClass('error');
               /* Show Stripe errors on the form */
               $form.find('.payment-errors').text('Try refreshing the page and trying again.');
               $form.find('.payment-errors').closest('.row').show();
           });
   }
});
}
/* Fancy restrictive input formatting via jQuery.payment library*/
$('input[name=cardNumber]').payment('formatCardNumber');
$('input[name=cardCVC]').payment('formatCardCVC');
$('input[name=cardExpiry').payment('formatCardExpiry');

/* Form validation using Stripe client-side validation helpers */
jQuery.validator.addMethod("cardNumber", function(value, element) {
return this.optional(element) || Stripe.card.validateCardNumber(value);
}, "Please specify a valid credit card number.");

jQuery.validator.addMethod("cardExpiry", function(value, element) {    
/* Parsing month/year uses jQuery.payment library */
value = $.payment.cardExpiryVal(value);
return this.optional(element) || Stripe.card.validateExpiry(value.month, value.year);
}, "Invalid expiration date.");

jQuery.validator.addMethod("cardCVC", function(value, element) {
return this.optional(element) || Stripe.card.validateCVC(value);
}, "Invalid CVC.");

validator = $form.validate({
rules: {
   cardNumber: {
       required: true,
       cardNumber: true            
   },
   cardExpiry: {
       required: true,
       cardExpiry: true
   },
   cardCVC: {
       required: true,
       cardCVC: true
   }
},
highlight: function(element) {
   $(element).closest('.form-control').removeClass('success').addClass('error');
},
unhighlight: function(element) {
   $(element).closest('.form-control').removeClass('error').addClass('success');
},
errorPlacement: function(error, element) {
   $(element).closest('.form-group').append(error);
}
});

paymentFormReady = function() {
if ($form.find('[name=cardNumber]').hasClass("success") &&
   $form.find('[name=cardExpiry]').hasClass("success") &&
   $form.find('[name=cardCVC]').val().length > 1) {
   return true;
} else {
   return false;
}
}

$form.find('[type=submit]').prop('disabled', true);
var readyInterval = setInterval(function() {
if (paymentFormReady()) {
   $form.find('[type=submit]').prop('disabled', false);
   clearInterval(readyInterval);
}
}, 250);
</script>
<style>
  input[type=radio] {
    width: 20px;
    height: 20px;
}
</style>
<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300" style="background-color: #656565;">

  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>


    <header class="site-navbar py-4 js-sticky-header site-navbar-target" role="banner">

      <div class="container-fluid">
        <div class="d-flex align-items-center">
          <div class="site-logo"><a href="index.html">ConVet Recommendation<span>.</span> </a></div>
          <div class="ml-auto">
            <nav class="site-navigation position-relative text-right" role="navigation">
              <ul class="site-menu main-menu js-clone-nav mr-auto d-none d-lg-block">
                <li><a href="pages/home.php" class="nav-link">Home</a></li>
                <li><a href="#services-section" class="nav-link">Services</a></li>
                <li><a href="#schedule-section" class="nav-link">Schedule</a></li>
                <li><a href="#contact-section" class="nav-link">Payment</a></li>
              </ul>
            </nav>
            <a href="#" class="d-inline-block d-lg-none site-menu-toggle js-menu-toggle float-right"><span class="icon-menu h3"></span></a>
          </div>

        </div>
      </div>

    </header>


    <div  id="home-section" style="background-color: #656565;">

      <div class="container" style="padding-top:100px;">
          <div class="col-lg-12 mx-auto text-center" data-aos="fade-up">
          <br><br><br>
            <h1 class="mb-3" style="color:white;"><strong>Looking for ?</strong></h1>
            <form action=" " method="POST" class="search-bar">
				<input type="search" name="search" pattern=".*\S.*" required>
				<button class="search-btn" name="submit" value="submit" type="submit">
					<span>Search</span>
				</button>
			</form>
        <?php
        if (isset($_POST["submit"])){
              $name=$_POST["search"];
              	echo "<div class='row'>";
               // echo "<div class='col-lg-4'></div>";
                        echo "<div class='col-lg-12'>";
                        
                 //check if form was submitted
                
        $host = "localhost";
        $dbUsername = "root";
        $dbPassword = "qwerty";
        $dbname = "fyp";
        
        //create connection
        $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
        if (mysqli_connect_error()) {
         die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
        } else {
          $sql = "SELECT pic,email,level,name FROM `registration` where `name` LIKE '%$name%' ";
          $result = $conn->query($sql);
          
          if ($result->num_rows > 0){
          
          $counterF=0;
          while($row = $result->fetch_assoc()) {
			  $counterF++;
          $path=$row['pic'];
          $email=$row['email'];
              $level=$row["level"];
            $Name=$row['name'];
            $int_level = (int)$level;
			
			echo "<div class='col-lg-4' style='display:inline;'>";
			if($counterF>3)
			{
				
				echo "<br>";
				echo "<br>";echo "<br>";
				$counterF=0;
			}
            echo "<div class='card' style='width:300px; height:200px;  text-align:center'>";  //this height property has made it transparent
            
			echo "<a href='profile_view.php?id=$Name'><img class='card-img-top' height='200px' src='images/$path' alt='' ></a>";
            echo "<div class='card-body'>";
            
			
                       
                  echo "<h5 class='card-title'><a href='profile_view.php?id=$Name' style='color:white;'>$Name</a>" ;
                  echo "</h5>";
                  echo "<h4 class='card-text'>";
                          
                  for ($i=0;$i<$int_level;$i++){
                    echo "<img src='images/star.png' height='30px' width='30px'/>";
                  }
                  echo "</h4>";
                  
                  $sq = "SELECT `email` FROM `registration` where `name`LIKE '%$name%'";
                 $resul = $conn->query($sq); 
                        //getting email of name searched
                        if (!$resul) {
                          trigger_error('Invalid query: ' . $conn->error);
                      }
                 if ($resul->num_rows > 0){
                   
                    $count=0;
                  while($row = $resul->fetch_assoc()) {
                    
                    if($counter<=$count){
                  $name1=$row['email'];       //to get first id
                  //echo $name1;
                  //echo $count;
                  //echo $counter;
                  break;
                    }
                    $count++;
                  }}
                  $counter++;
                    
                  $sql1 = "SELECT friend FROM `friend` where `friend`='$name1' && `name`='$id2' ";
                 $result1 = $conn->query($sql1);
                 if ($result1->num_rows > 0){
                  echo "<a href='friend_del.php?id=$email' class='btn btn-success'>Remove Friend</a>";
                 }else{
                  echo "<a href='friend.php?id=$email' class='btn btn-primary'>ADD Friend</a>";
                 }
				 

                  echo "</div>";
			
                  echo "</div>";

              
              
            }
          }else{
            echo "<br>No result found!";
          }
            
                  } 
                echo "</div>";
                echo "</div>";
                }
              ?>
        
          </div>
        </div>

      </div>
    </div>
	</div>
    
  <!-- .site-wrap -->

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.fancybox.min.js"></script>
  <script src="js/jquery.sticky.js"></script>
  <script src="js/jquery.mb.YTPlayer.min.js"></script>




  <script src="js/main.js"></script>

</body>
</html>