<?php
session_start();
$id=$_SESSION['id'];        // the one jiska friend hoga
$id2=$_GET['friend']; 
    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "qwerty";
    $dbname = "fyp";
    //create connection
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    if (mysqli_connect_error()) {
     die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    } else {

      $SELECT = "SELECT friend FROM `friend` where `friend`='$id2' && `name`='$id' ";   //to check pehly s tu dost nhe
      $result = $conn->query($SELECT);
      if (!$result) {
        trigger_error('Invalid query: ' . $conn->error);
    }
      if ($result->num_rows > 0){
      while($row = $result->fetch_assoc()) {
        $name=$row['friend'];
      }
      if ($name==$id2){
        
        $SELECT1 = "Delete from `friend` where name='$id' && friend='$id2'";
        $result1 = $conn->query($SELECT1);
		?>
		<html>
		<body onload="myFunction()">
		<script>
		function myFunction() {
		alert("Removed Friend");
		}
		</script>
		</body></html>
		<?php
        header("Refresh:1; url=news_Feed.php");
        //echo "query : ".$SELECT1;
		//echo "name : ".$id;
		//echo "friend name : ".$id2;
      }
      }
$conn->close();
    }
	?>
	