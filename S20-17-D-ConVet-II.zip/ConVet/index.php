<?php
$host = "localhost";
$dbUsername = "root";
$dbPassword = "YES";
$dbname = "fyp";
$answer;
@$a=$_POST['serviceName'];  
@$b=$_POST['Date']; 
if(isset($_POST['submit1'])){
$position=$_POST['jobPosition']; 


$salary=$_POST['salary']; 


$duration=$_POST['jobDuration']; 

$description=$_POST['jobDescription'];
}
$id2=$_GET['id1'];
//create connection
$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
if (mysqli_connect_error()) {
 die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
} else {  
if(@$_POST['submit'] || @$_POST['submit1'])  
{  
$check=$a;
$sql = "SELECT * FROM `adminservice`;";
        $result = $conn->query($sql);
		if ($result->num_rows > 0) {
			while($row = $result->fetch_assoc()) {
			if($row['name']==$a)
			{
				$path=$row['image'];
			}
		}
		}
$s="insert into services(serviceName,Date,startedBy,imagePath) values('$a','$b','$id2','images/$path')";  
mysqli_query($conn, $s);
$path1=1;
	$sql1 = "SELECT id FROM `services`;";
        $result1 = $conn->query($sql1);
		if ($result1->num_rows > 0) {
			while($row = $result1->fetch_assoc()) {
			
				$path1=$row['id'];
			
		}
		}
		
		 if (isset($_POST['jobPosition']) && isset($_POST['salary']) && isset($_POST['jobDuration']) && isset($_POST['jobDescription']) && isset($_POST['submit1'])  )
{
$myfile = fopen("ConVet-master/myfile.txt", "r") or die("Unable to open file!");
$category=fgets($myfile);
	$ss="insert into job(jobPosition,salary,jobDuration,jobDescription,category,id) values('$position','$salary','$duration','$description','$category','$path1')";  
	mysqli_query($conn, $ss);
	
	echo '<script>alert("Done!!")</script>'; 
	
}else{
	echo '<script>alert("Query not worked")</script>'; 
}	
header("refresh 5;url=pages/orderdone.php?$id2");
} 
} 
  ?> 
<!DOCTYPE html>
<html lang="en">

<head>
  <title>ConVet &mdash; Connecting People</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  
  <link href="https://fonts.googleapis.com/css?family=Muli:300,400,700,900" rel="stylesheet">
  <link rel="stylesheet" href="fonts/icomoon/style.css">

  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/jquery-ui.css">
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">

  <link rel="stylesheet" href="css/jquery.fancybox.min.css">

  <link rel="stylesheet" href="css/bootstrap-datepicker.css">

  <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

  <link rel="stylesheet" href="css/aos.css">
  <link href="css/jquery.mb.YTPlayer.min.css" media="all" rel="stylesheet" type="text/css">

  <link rel="stylesheet" href="css/style.css">
      <style>
.dropbtn {
  background-color: #4CAF50;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
  cursor: pointer;
}

.dropbtn:hover, .dropbtn:focus {
  background-color: #3e8e41;
}

#myInput {
  box-sizing: border-box;
  background-image: url('searchicon.png');
  background-position: 14px 12px;
  background-repeat: no-repeat;
  font-size: 16px;
  padding: 14px 20px 12px 45px;
  border: none;
  border-bottom: 1px solid #ddd;
}

#myInput:focus {outline: 3px solid #ddd;}

.dropdown {
  position: relative;
  display: inline-block;

}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f6f6f6;
  min-width: 230px;
  overflow: auto;
  border: 1px solid #ddd;
  z-index: 1;
  height:300px;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  size:5;
}

.dropdown a:hover {background-color: #ddd;}

.show {display: block;}
</style>



</head>
<script>
  var $form = $('#payment-form');
$form.on('submit', payWithStripe);

/* If you're using Stripe for payments */
function payWithStripe(e) {
e.preventDefault();

/* Visual feedback */
$form.find('[type=submit]').html('Validating <i class="fa fa-spinner fa-pulse"></i>');

var PublishableKey = 'pk_test_b1qXXwATmiaA1VDJ1mOVVO1p'; // Replace with your API publishable key
Stripe.setPublishableKey(PublishableKey);

/* Create token */
var expiry = $form.find('[name=cardExpiry]').payment('cardExpiryVal');
var ccData = {
   number: $form.find('[name=cardNumber]').val().replace(/\s/g,''),
   cvc: $form.find('[name=cardCVC]').val(),
   exp_month: expiry.month, 
   exp_year: expiry.year
};

Stripe.card.createToken(ccData, function stripeResponseHandler(status, response) {
   if (response.error) {
       /* Visual feedback */
       $form.find('[type=submit]').html('Try again');
       /* Show Stripe errors on the form */
       $form.find('.payment-errors').text(response.error.message);
       $form.find('.payment-errors').closest('.row').show();
   } else {
       /* Visual feedback */
       $form.find('[type=submit]').html('Processing <i class="fa fa-spinner fa-pulse"></i>');
       /* Hide Stripe errors on the form */
       $form.find('.payment-errors').closest('.row').hide();
       $form.find('.payment-errors').text("");
       // response contains id and card, which contains additional card details            
       console.log(response.id);
       console.log(response.card);
       var token = response.id;
       // AJAX - you would send 'token' to your server here.
       $.post('/account/stripe_card_token', {
               token: token
           })
           // Assign handlers immediately after making the request,
           .done(function(data, textStatus, jqXHR) {
               $form.find('[type=submit]').html('Payment successful <i class="fa fa-check"></i>').prop('disabled', true);
           })
           .fail(function(jqXHR, textStatus, errorThrown) {
               $form.find('[type=submit]').html('There was a problem').removeClass('success').addClass('error');
               /* Show Stripe errors on the form */
               $form.find('.payment-errors').text('Try refreshing the page and trying again.');
               $form.find('.payment-errors').closest('.row').show();
           });
   }
});
}
/* Fancy restrictive input formatting via jQuery.payment library*/
$('input[name=cardNumber]').payment('formatCardNumber');
$('input[name=cardCVC]').payment('formatCardCVC');
$('input[name=cardExpiry').payment('formatCardExpiry');

/* Form validation using Stripe client-side validation helpers */
jQuery.validator.addMethod("cardNumber", function(value, element) {
return this.optional(element) || Stripe.card.validateCardNumber(value);
}, "Please specify a valid credit card number.");

jQuery.validator.addMethod("cardExpiry", function(value, element) {    
/* Parsing month/year uses jQuery.payment library */
value = $.payment.cardExpiryVal(value);
return this.optional(element) || Stripe.card.validateExpiry(value.month, value.year);
}, "Invalid expiration date.");

jQuery.validator.addMethod("cardCVC", function(value, element) {
return this.optional(element) || Stripe.card.validateCVC(value);
}, "Invalid CVC.");

validator = $form.validate({
rules: {
   cardNumber: {
       required: true,
       cardNumber: true            
   },
   cardExpiry: {
       required: true,
       cardExpiry: true
   },
   cardCVC: {
       required: true,
       cardCVC: true
   }
},
highlight: function(element) {
   $(element).closest('.form-control').removeClass('success').addClass('error');
},
unhighlight: function(element) {
   $(element).closest('.form-control').removeClass('error').addClass('success');
},
errorPlacement: function(error, element) {
   $(element).closest('.form-group').append(error);
}
});

paymentFormReady = function() {
if ($form.find('[name=cardNumber]').hasClass("success") &&
   $form.find('[name=cardExpiry]').hasClass("success") &&
   $form.find('[name=cardCVC]').val().length > 1) {
   return true;
} else {
   return false;
}
}

$form.find('[type=submit]').prop('disabled', true);
var readyInterval = setInterval(function() {
if (paymentFormReady()) {
   $form.find('[type=submit]').prop('disabled', false);
   clearInterval(readyInterval);
}
}, 250);
</script>
<style>
  input[type=radio] {
    width: 20px;
    height: 20px;
}
</style>
<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">

  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>


    <header class="site-navbar py-4 js-sticky-header site-navbar-target" role="banner">

      <div class="container-fluid">
        <div class="d-flex align-items-center">
          <div class="site-logo"><a href="index.html">ConVet<span>.</span> </a></div>
          <div class="ml-auto">
            <nav class="site-navigation position-relative text-right" role="navigation">
              <ul class="site-menu main-menu js-clone-nav mr-auto d-none d-lg-block">
                <li><a href="pages/home.php" class="nav-link">Home</a></li>
                <li><a href="#services-section" class="nav-link">Services</a></li>
                <li><a href="application_status.php" class="nav-link">Application Status</a></li>
                <li><a href="pages/login.html" class="nav-link">I am organization</a></li>
              </ul>
            </nav>
            <a href="#" class="d-inline-block d-lg-none site-menu-toggle js-menu-toggle float-right"><span class="icon-menu h3"></span></a>
          </div>

        </div>
      </div>

    </header>


    <div class="intro-section" id="home-section" style="background-color: #ccc;">

      <div class="container">

        <div class="row align-items-center">
          <div class="col-lg-12 mx-auto text-center" data-aos="fade-up">
            <h1 class="mb-3">ConVet</h1>
            <p class="lead mx-auto desc mb-5">Services block where you can select the desired service from the services below, Schedule the meeting
              and Go through the Payment process. So, what are you waiting let's,
            </p>
            <p class="text-center">
              <a href="#services-section" class="btn btn-outline-white py-3 px-5">Get Started</a>
            </p>
          </div>
        </div>

      </div>
    </div>

    <div class="site-section" id="services-section">
      <div class="container">
        <div class="row justify-content-center text-center mb-5" data-aos="fade-up">
          <div class="col-md-8  section-heading">
            <h2 class="heading mb-3">Services</h2>
            
          </div>
        </div>
		<div class="row">
		<?php 
		$servername = "localhost";
        $username = "username";
        $password = "qwerty";
        $dbname = "fyp";
        
        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $sql = "SELECT * FROM `adminservice`;";
        $result = $conn->query($sql);
		if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
	?>

        
          <div class="col-lg-4 mb-4 col-md-6" data-aos="fade-up" data-aos-delay="100">
            <div class="ftco-feature-1">
              <span>
			  
			  <img class="img-fluid" src="images/<?php echo $row['image'];?>" height="400px" width="400px" alt=""></span>
              <div class="ftco-feature-1-text">
                <h2><?php echo $row['name'];?></h2>
		<p><?php echo $row['description']; ?></p>
              </div>
            </div>
			
          </div>
<?php }}?>
        </div>
      </div>
    </div>
    
    
    <div class="site-section" id="schedule-section" style="padding-bottom:0%;">
      <div class="container">
        <div class="row justify-content-center text-center mb-5">
          <div class="col-md-8  section-heading">
            <h2 class="heading mb-3">Schedule</h2>
          </div>
        </div>

        
        <div class="row">
          <div class="col-12">
            <ul class="nav days d-flex" role="tablist">
              <li class="nav-item">
                <a class="nav-link active" id="sunday-tab" data-toggle="tab" href="#nav-sunday" role="tab" aria-controls="sunday"
                  aria-selected="true">S</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="monday-tab" data-toggle="tab" href="#nav-monday" role="tab" aria-controls="monday"
                  aria-selected="false">M</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="tuesday-tab" data-toggle="tab" href="#nav-tuesday" role="tab" aria-controls="tuesday"
                  aria-selected="false">T</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="wednesday-tab" data-toggle="tab" href="#nav-wednesday" role="tab" aria-controls="wednesday"
                  aria-selected="false">W</a>
              </li>

              <li class="nav-item">
                <a class="nav-link" id="thursday-tab" data-toggle="tab" href="#nav-thursday" role="tab" aria-controls="thursday"
                  aria-selected="false">T</a>
              </li><li class="nav-item">
                <a class="nav-link" id="friday-tab" data-toggle="tab" href="#nav-friday" role="tab" aria-controls="friday"
                  aria-selected="false">F</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="saturday-tab" data-toggle="tab" href="#nav-saturday" role="tab" aria-controls="saturday"
                  aria-selected="false">S</a>
              </li>
            </ul>
          </div>
        </div>
		

        <div class="tab-content">
          <div class="tab-pane fade show active" id="nav-sunday" role="tabpanel" aria-labelledby="nav-sunday-tab">
            <div class="row">
              <div class="col-lg-1"></div>
              <div class="col-lg-6">
                <h2><strong>Check a service from below and then set time and Date</strong></h2>
                <form method="post">
				
                <div class="form-check">
				<?php 
		$sql = "SELECT distinct(name) FROM `adminservice`;";
        $result = $conn->query($sql);
		if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {?>
                  <input class="form-check-input" type="radio" name="serviceName" id="exampleRadios1" value="<?php echo $row['name'];?>">
                  
				  <label class="form-check-label" for="exampleRadios1">
		<h3 style=""><?php echo $row['name'];echo "<br><br>";}}?></h3>
                  </label>
                </div>
            </div>
              <div class="col-lg-4">
              <br><br><br><br>
              <h2><strong>Set Date and Time</strong></h2>
                  <label for="birthdaytime">Service (date and time):</label>
                  <input type="datetime-local" id="birthdaytime" name="Date" required>
                  <br><br>
                 <!-- <a href=""><input class="btn btn-primary" type="submit" name="submit" value="Apply for this service"></a> -->
              <!--</form> -->
              </div>
          </div>
          <div class="tab-pane fade" id="nav-monday" role="tabpanel" aria-labelledby="nav-monday-tab">
          </div>
          <div class="tab-pane fade" id="nav-tuesday" role="tabpanel" aria-labelledby="nav-tuesday-tab">
            
          </div>
          <div class="tab-pane fade" id="nav-wednesday" role="tabpanel" aria-labelledby="nav-wednesday-tab">
            
          </div>

          <div class="tab-pane fade" id="nav-thursday" role="tabpanel" aria-labelledby="nav-thursday-tab">
            
          </div>
          <div class="tab-pane fade" id="nav-friday" role="tabpanel" aria-labelledby="nav-friday-tab">
            
          </div>
          <div class="tab-pane fade" id="nav-saturday" role="tabpanel" aria-labelledby="nav-saturday-tab">
            
          </div>
        </div>
        
      </div>
      <br>
    </div>
    <div class="site-section bg-dark contact-wrap" id="contact-section">
      <div class="container">
        
        <div class="row justify-content-center text-center mb-5">
          <div class="col-md-8  section-heading">
            <span class="subheading">Get In Touch</span>
            <h2 class="heading mb-3">Payment Details</h2>
          </div>
        </div>
        <div class="row">
<div class="col-lg-3"></div>
<div class="col-lg-2">
<button type="button" class="btn btn-outline-white py-3 px-5" onclick="myFunction()">Paid ?</button>
</div>
<div class="col-lg-2"></div>
<div class="col-lg-4">
<a href=""><input class="btn btn-outline-white py-3 px-5" type="submit" name="submit" value="Start Service"></a>
<!--<button class="btn btn-outline-white py-3 px-5" onclick="myFunction1()">Unpaid ?</button> -->
</div>

<script>
function myFunction() {
  var x = document.getElementById("myDIV");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
function myFunction1() {
  var x = document.getElementById("myDIV1");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
</script>
<div id="myDIV" style="display: none;">
  <div class="row">

    <div class="col-lg-2"></div>
<!-- You can make it whatever width you want. I'm making it full width
on <= small devices and 4/12 page width on >= medium devices -->
<div class="col-xs-12 col-lg-10" style="padding-top: 100px;">


<!-- CREDIT CARD FORM STARTS HERE -->
<div class="panel panel-default credit-card-box">
<div class="panel-heading display-table" >
<div class="row display-tr" >&nbsp;&nbsp;&nbsp;&nbsp;
<h3 class="panel-title display-td"style="color:white;" >Paid Job Details</h3>
<button type="button" id="button2" onclick="myFunction2()" style="border-radius:8px;padding-left:20px;margin-left:30px;" class="dropbtn">Add Required Skills</button>
</div>                    
</div>
<div class="panel-body">
<div class="row">
<div class="col-xs-80">
                            
</div>
</div>
<div class="row">
  <div class="form-group">
    <label for="cardNumber" style="color:white;" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Position</label>
    <div  class="input-group" style="padding-left: 20px;">
    <input  type="tel" class="form-control" name="jobPosition" placeholder="Job Position" autocomplete="cc-number"  autofocus />
    <span class="input-group-addon"><i class="fa fa-credit-card"></i></span>
    </div>
    </div>
	
  
  <div id="myDropdown" class="dropdown-content" size="5">
    <input type="text" placeholder="Search.." id="myInput" onkeyup="filterFunction()">
    
	<?php
$myfile = fopen("skills.txt", "r") or die("Unable to open file!");
// Output one line until end-of-file
while(!feof($myfile)) {
	$value=fgets($myfile); ?>
  <a href='javascript:myFunction1("<?php echo $value; ?>");'><?php echo $value; ?> </a>
  <?php
 
}
fclose($myfile);
?>
  </div>
</div>
<script>
var skills="";
var editedText="";
document.getElementById("demo").innerHTML = skills;

function myFunction1(y) {
  skills+=y+",";
  editedText = skills.slice(0, -1)
  alert("You have added : "+editedText);
	$.get("http://localhost:5000/predict?skills="+editedText);
  document.getElementById("demo").innerHTML = "You have added : "+editedText;
  document.getElementById("skills").value =  editedText;
  //alert("Added "+y);
}
	  
</script>

<script>
function myFunction2() {
  document.getElementById("myDropdown").classList.toggle("show");
}

function filterFunction() {
  var input, filter, ul, li, a, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  div = document.getElementById("myDropdown");
  a = div.getElementsByTagName("a");
  for (i = 0; i < a.length; i++) {
    txtValue = a[i].textContent || a[i].innerText;
    if (txtValue.toUpperCase().indexOf(filter) > -1) {
      a[i].style.display = "";
    } else {
      a[i].style.display = "none";
    }
  }
}
</script>
<div class="form-group">
<label for="cardExpiry"><span class="hidden-xs" style="color:white;" >Job Duration</span></label>
<input type="text" class="form-control" name="jobDuration"placeholder="No.of days"autocomplete="cc-exp" />
</div>
<div class="form-group">
<label for="cardCVC" style="color:white;" >Salary</label>
<input 
type="tel" class="form-control"name="salary"placeholder="Enter salary you will pay"autocomplete="cc-csc" />
</div>
</div>
<div class="row">
<div class="col-xs-12 col-md-12">
<div class="form-group">
<label for="couponCode" style="color:white;" >Job Description</label>
<input type="text" class="form-control" name="jobDescription" placeholder="Job Description" />
</div>
</div>                        
</div>
<div class="row" style="padding-left: 20px;">
<div class="col-xs-12" style="padding-top: 10px;"style="padding-left: 20px;">
<p style="text-align: center;">
  </p>
</div>
</div>
</div>
</div>      
<!-- CREDIT CARD FORM ENDS HERE -->


</div>       
<a href=""><input class="btn btn-outline-white py-3 px-5" style="margin-left:303px;"type="submit" name="submit1" value="Start Service"></a>

  </div>
  </form>
  <div id="myDIV1" style="display: none;">
    <div class="row">
  
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <!-- You can make it whatever width you want. I'm making it full width
  on <= small devices and 4/12 page width on >= medium devices -->
  <div class="col-lg-4"></div>
  <div class="col-xs-12 col-lg-10" style="padding-top: 10px;">
  <div class="col-lg-2"></div>
  
  <!-- CREDIT CARD FORM STARTS HERE -->
  <div class="panel panel-default credit-card-box">
  <div class="panel-heading display-table" >
  <div class="row display-tr" >
  <h3 class="panel-title display-td"style="color:white;" >Payment Details</h3>
  <div style="display: inline;" class="display-td" >                            
  <img class="img-responsive pull-right" src="http://i76.imgup.net/accepted_c22e0.png" style="padding-left: 60px;">
  </div>
  </div>                    
  </div>
  <div class="panel-body">
  <form role="form" id="payment-form">
  <div class="row">
  <div class="col-xs-80">
                              
  </div>
  </div>
  <div class="row">
    <div class="form-group">
      <label for="cardNumber" style="color:white;" >Account Number</label>
      <div  class="input-group" style="padding-left: 20px;">
      <input  
      type="tel"
      class="form-control"
      name="cardNumber"
      placeholder="Valid Account Number"
      autocomplete="cc-number"
      required autofocus 
      />
      <span class="input-group-addon"><i class="fa fa-credit-card"></i></span>
      </div>
      </div>
  </div>
  <div class="row" style="padding-left: 20px;">
  <div class="col-xs-12" style="padding-top: 10px;"style="padding-left: 20px;">
  <p style="text-align: center;">
      <button class="btn btn-primary" onclick="location.href='pages/orderdone.php?<?php echo $id2 ?>'" type="button">
        Confirm Payment</button>
    </p>
  </div>
  </div>
  </form>
  </div>
  </div>      
  <!-- CREDIT CARD FORM ENDS HERE -->
  
  
  </div>            
  
  
  
  </div>
    </div>
      </div>
    </div>
  </div>
    
      </div>
    </div>
  </div>
    
    <footer class="pt-5 pb-4" id="contact">
			<div class="container">
				<div class="row">
					<div class="col-lg-6">
						<h5 class="mb-8 font-weight-bold">ABOUT US</h5><br>
						<ul class="f-address">
							<li>
								<div class="row">
									<div class="col-1"><i class="fas fa-map-marker"></i></div>
                
							</li>
							<li>
								<div class="row">
									<div class="col-1"><i class="far fa-envelope"></i></div>
									<div class="col-10">
										<h6 class="font-weight-bold mb-0">Have any questions?</h6>
										<p><a href="pages/complain.html">Support@Convet.com</a></p>
									</div>
								</div>
							</li>
							<li>
								<div class="row">
									<div class="col-1"><i class="fas fa-phone-volume"></i></div>
									<div class="col-10">
										<h6 class="font-weight-bold mb-0">Phone No:</h6>
										<p><a href="#">+92 (0) 51-33-33211-33312</a></p>
									</div>
								</div>
              </li>
              
						</ul>
					</div>
					<div class="col-lg-3 col-md-6 col-sm-6 mt-2 mb-4">
						<ul class="f-address">
						</ul>
					</div>
					
          </div>
          
				</div>
			</div>
		</footer>
		<!-- Copyright -->
		<section class="copyright">
			<div class="container">
				<div class="row">
					<div class="col-md-12 ">
						<div class="text-center text-black" style="padding-bottom: 50px;">
							&copy; <strong>2019 All Rights Reserved.</strong>
						</div>
					</div>
				</div>
			</div>
		</section>
    
  <!-- .site-wrap -->

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.fancybox.min.js"></script>
  <script src="js/jquery.sticky.js"></script>
  <script src="js/jquery.mb.YTPlayer.min.js"></script>
  <script src="js/main.js"></script>

</body>
</html>