<?php
session_start();
$id=$_SESSION['id'];        // the one jiska friend hoga
$id2=$_GET['friend']; 
    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "qwerty";
    $dbname = "fyp";
    //create connection
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    if (mysqli_connect_error()) {
     die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    } else {

      $SELECT = "SELECT id FROM `appliedjob` where `id`='$id2' && `applier`='$id' ";   //to check pehly s tu dost nhe
      $result = $conn->query($SELECT);
      if (!$result) {
        trigger_error('Invalid query: ' . $conn->error);
    }
      if ($result->num_rows > 0){
      while($row = $result->fetch_assoc()) {
        $name=$row['id'];
      }
      if ($name==$id2){
        
        header("location:news_Feed.php?id=$id");
        
      }
      }else{
        $SELECT1 = "INSERT INTO `appliedjob`(`id`, `applier`) VALUES ('$id2','$id')";
        $result1 = $conn->query($SELECT1);
		?>
		<html>
		<body onload="myFunction()">
		<script>
		function myFunction() {
		alert("Applied for Job");
		}
		</script>
		</body></html>
		<?php
        header("refresh:0,url=news_Feed.php?id=$id");
      }
$conn->close();
    }
	?>
	