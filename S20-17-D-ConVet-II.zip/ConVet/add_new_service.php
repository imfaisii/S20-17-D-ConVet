<?php
session_start();
$id2=$_SESSION['id'];
$host = "localhost";
$dbUsername = "root";
$dbPassword = "qwerty";
$dbname = "fyp";

//create connection
$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
if (mysqli_connect_error()) {
 die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
} else {
  $sql = "SELECT name FROM `registration` where `name` = 'Faisal'";
  $result = $conn->query($sql);
  
  
  
  
  while($row = $result->fetch_assoc()) {
      
      $Name=$row['name'];
      
	  }


	  $sql1 = "SELECT count(name) as user FROM `registration` ";
	  $result1 = $conn->query($sql1);
	  
	  
	  
	  
	  while($row = $result1->fetch_assoc()) {
		  
		  $users=$row['user'];
		  
		  }
	  
		  $sql2 = "SELECT count(serviceName) as user FROM `services` ";
		  $result2 = $conn->query($sql2);
		  
		  
		  
		  
		  while($row = $result2->fetch_assoc()) {
			  
			  $services=$row['user'];
			  
			  }
		  
			  $sql3 = "SELECT count(joinedBy) as user FROM `appliedusers` ";
			  $result3 = $conn->query($sql3);
			  
			  
			  
			  
			  while($row = $result3->fetch_assoc()) {
				  
				  $appliedpeople=$row['user'];
				  
				  }
			  
    }
?>
<!doctype html>
<html lang="en">
  <head>
  	<title>Admin panel</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css1/style.css">
	<style>
		.border-box{
			border: 1px light black;
		  box-sizing: border-box;
		  border-style:solid solid none;
		  background-color:#fffff
		}
		.center{
			text-align:center;

		}
		Tools
Sign In
Search
Bootstrap Search
Bootstrap search is a component which enables the user to find words, sentences, and numbers in a collection of documents, web pages or other sources.

It can be implemented with buttons or icons, than placed as an input or in a navbar for an even better user experience.

Examples of Bootstrap search use:

Databases
Search engines
Built-in search box on a documentation page (like the one on the left)
You can use the Material Design version or the default Bootstrap style.

Basic example
Search
HTML
<!-- Search form -->
<div class="md-form mt-0">
  <input class="form-control" type="text" placeholder="Search" aria-label="Search">
</div>
Search
HTML
<!-- Search form -->
<input class="form-control" type="text" placeholder="Search" aria-label="Search">
Search with colorful border
Always colorful or only in the :focus state.

Search
Search
Search
Search
Search
Search
HTML
CSS
<!-- Search form -->
<div class="md-form active-pink active-pink-2 mb-3 mt-0">
  <input class="form-control" type="text" placeholder="Search" aria-label="Search">
</div>
<!-- Search form -->
<div class="md-form active-purple active-purple-2 mb-3">
  <input class="form-control" type="text" placeholder="Search" aria-label="Search">
</div>
<!-- Search form -->
<div class="md-form active-cyan active-cyan-2 mb-3">
  <input class="form-control" type="text" placeholder="Search" aria-label="Search">
</div>

<!-- Search form -->
<div class="md-form active-pink-2 mb-3">
  <input class="form-control" type="text" placeholder="Search" aria-label="Search">
</div>
<!-- Search form -->
<div class="md-form active-purple-2 mb-3">
  <input class="form-control" type="text" placeholder="Search" aria-label="Search">
</div>
<!-- Search form -->
<div class="md-form active-cyan-2 mb-3">
  <input class="form-control" type="text" placeholder="Search" aria-label="Search">
</div>
Search
Search
Search
Search
Search
Search
HTML
CSS
<!-- Search form -->
<div class="active-pink-3 active-pink-4 mb-4">
  <input class="form-control" type="text" placeholder="Search" aria-label="Search">
</div>
<!-- Search form -->
<div class="active-purple-3 active-purple-4 mb-4">
  <input class="form-control" type="text" placeholder="Search" aria-label="Search">
</div>
<!-- Search form -->
<div class="active-cyan-3 active-cyan-4 mb-4">
  <input class="form-control" type="text" placeholder="Search" aria-label="Search">
</div>

<!-- Search form -->
<div class="active-pink-4 mb-4">
  <input class="form-control" type="text" placeholder="Search" aria-label="Search">
</div>
<!-- Search form -->
<div class="active-purple-4 mb-4">
  <input class="form-control" type="text" placeholder="Search" aria-label="Search">
</div>
<!-- Search form -->
<div class="active-cyan-4 mb-4">
  <input class="form-control" type="text" placeholder="Search" aria-label="Search">
</div>
Search with icon
Always colorful or only in the :focus state.

Search
Search
Search
Search
Search
Search
Search
Search
HTML
CSS
<!-- Search form -->
<form class="form-inline d-flex justify-content-center md-form form-sm mt-0">
  <i class="fas fa-search" aria-hidden="true"></i>
  <input class="form-control form-control-sm ml-3 w-75" type="text" placeholder="Search"
    aria-label="Search">
</form>

<!-- Search form -->
<form class="form-inline d-flex justify-content-center md-form form-sm active-pink active-pink-2 mt-2">
  <i class="fas fa-search" aria-hidden="true"></i>
  <input class="form-control form-control-sm ml-3 w-75" type="text" placeholder="Search"
    aria-label="Search">
</form>

<!-- Search form -->
<form class="form-inline d-flex justify-content-center md-form form-sm active-purple active-purple-2 mt-2">
  <i class="fas fa-search" aria-hidden="true"></i>
  <input class="form-control form-control-sm ml-3 w-75" type="text" placeholder="Search"
    aria-label="Search">
</form>

<!-- Search form -->
<form class="form-inline d-flex justify-content-center md-form form-sm active-cyan active-cyan-2 mt-2">
  <i class="fas fa-search" aria-hidden="true"></i>
  <input class="form-control form-control-sm ml-3 w-75" type="text" placeholder="Search"
    aria-label="Search">
</form>

<!-- Search form -->
<form class="form-inline d-flex justify-content-center md-form form-sm">
  <input class="form-control form-control-sm mr-3 w-75" type="text" placeholder="Search"
    aria-label="Search">
  <i class="fas fa-search" aria-hidden="true"></i>
</form>

<!-- Search form -->
<form class="form-inline d-flex justify-content-center md-form form-sm active-pink-2 mt-2">
  <input class="form-control form-control-sm mr-3 w-75" type="text" placeholder="Search"
    aria-label="Search">
  <i class="fas fa-search" aria-hidden="true"></i>
</form>

<!-- Search form -->
<form class="form-inline d-flex justify-content-center md-form form-sm active-purple-2 mt-2">
  <input class="form-control form-control-sm mr-3 w-75" type="text" placeholder="Search"
    aria-label="Search">
  <i class="fas fa-search" aria-hidden="true"></i>
</form>

<!-- Search form -->
<form class="form-inline d-flex justify-content-center md-form form-sm active-cyan-2 mt-2">
  <input class="form-control form-control-sm mr-3 w-75" type="text" placeholder="Search"
    aria-label="Search">
  <i class="fas fa-search" aria-hidden="true"></i>
</form>
Search
Search
Search
Search
Search
Search
Search
Search
HTML
CSS
.active-pink-2 input[type=text]:focus:not([readonly]) {
  border-bottom: 1px solid #f48fb1;
  box-shadow: 0 1px 0 0 #f48fb1;
}
.active-pink input[type=text] {
  border-bottom: 1px solid #f48fb1;
  box-shadow: 0 1px 0 0 #f48fb1;
}
.active-purple-2 input[type=text]:focus:not([readonly]) {
  border-bottom: 1px solid #ce93d8;
  box-shadow: 0 1px 0 0 #ce93d8;
}
.active-purple input[type=text] {
  border-bottom: 1px solid #ce93d8;
  box-shadow: 0 1px 0 0 #ce93d8;
}
.active-cyan-2 input[type=text]:focus:not([readonly]) {
  border-bottom: 1px solid #4dd0e1;
  box-shadow: 0 1px 0 0 #4dd0e1;
}
.active-cyan input[type=text] {
  border-bottom: 1px solid #4dd0e1;
  box-shadow: 0 1px 0 0 #4dd0e1;
}
.active-cyan .fa, .active-cyan-2 .fa {
  color: #4dd0e1;
}
.active-purple .fa, .active-purple-2 .fa {
  color: #ce93d8;
}
.active-pink .fa, .active-pink-2 .fa {
  color: #f48fb1;
}
		</style>
	</head>
  <body>
		
		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<div class="custom-menu">
					<button type="button" id="sidebarCollapse" class="btn btn-primary">
	          <i class="fa fa-bars"></i>
	          <span class="sr-only">Toggle Menu</span>
	        </button>
        </div>
				<div class="p-4">
		  		<h1><a href="#" class="logo">ConVet <span>Enjoy your oldage!</span></a></h1>
	        <ul class="list-unstyled components mb-5">
	          <li >
	            <a href="adminHamza.php?id= <?php echo $id2?>"><span class="fa fa-home mr-3"></span> Home</a>
	          </li>
	          <li>
	              <a href="admin_user.php"><span class="fa fa-user mr-3"></span> Users</a>
	          </li>
	          <li>
              <a href="admin_services.php"><span class="fa fa-briefcase mr-3"></span> Services</a>
	          </li>
			  <li>
              <a href="admin_applied_services.php"><span class="fa fa-briefcase mr-3"></span>Applied By</a>
	          </li>
			  <li class="active">
              <a href="add_new_service.php"><span class="fa fa-briefcase mr-3"></span>Add a new Service</a>
	          </li>
	        </ul>

	        <div class="mb-5">
						
	            

	       

	      </div>
    	</nav>

        <!-- Page Content  -->
      <div id="content" class="p-4 p-md-5 pt-5">
		<h2 class="mb-4">Welcome to Admin Panel</h2>
		<p>Hi <?php echo $Name;?>, Here you can manage the convet</p>
			<div class="row">
				<div class="col-lg-2">
					<h1 class="border-box">Users</h1>
					<p class="center"><?php echo $users; ?></p>
				</div>
				<div class="col-lg-6">
					<h1 class="border-box">Services in Progress</h1>
					<p class="center"><?php echo $services; ?></p>
				</div>
				<div class="col-lg-4">
					<h1 class="border-box">Applied Users</h1>
					<p class="center"><?php echo $appliedpeople; ?></p>
				</div>


			</div>
			<!--search form !-->
			<div class="row">
				
			<div class="col-lg-2"></div>
			<div class="col-lg-8">
			<h4 class="center">Add a new Service</h4>
				<br>
			<form style="text-align:center" action ="" method="post" class="form-inline" enctype= "multipart/form-data">
			<div class="input-group">
                      <input name="serviceName" class="input--style-2" type="text" placeholder="Service Name" required>
            </div>
			<br>
            <div class="input-group">
		
                    <input name="serviceDescription" class="input--style-2" type="text" size="50" placeholder="Description" required>
            
			</div>
			
					<div >
					<br>
					Select image to upload:
					<input type="file" name="fileToUpload" id="fileToUpload">
					</div>
					
                            <div class="p-t-30">
                                <br>
                                <input style="color:white;" class="btn btn-danger" name="submit" type="submit" value="Create A new Service">
                                
                            </div>
		</form>
			<?php
				echo "<div class='row'>";
				echo "<div class='col-lg-2'></div>";
				echo "<div class='col-lg-8'>";
				if(isset($_POST["submit"])){
					$serviceName = $_POST['serviceName']; //get input text
					$serviceDescription = $_POST['serviceDescription']; //get input text
					
$target_dir = "images/";
$file_name=basename($_FILES["fileToUpload"]["name"]);
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
  $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
  if($check !== false) {
    $uploadOk = 1;
  } else {
    $uploadOk = 0;
  }
}



// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
  echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
  $uploadOk = 0;
}

// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
  echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
  if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
					$host = "localhost";
$dbUsername = "root";
$dbPassword = "qwerty";
$dbname = "fyp";

//create connection
$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
if (mysqli_connect_error()) {
 die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
} else {
  $sql = "INSERT INTO `adminservice`(`name`, `description`, `image`) VALUES ('$serviceName','$serviceDescription','$file_name')";
  if($result = $conn->query($sql))
  {
	  echo "Added succesfully!!";
  }
  else
  {
	  echo "Please enter details";
  }
  
  
  
}
  }
				}}
				
				
			?>
			</div>
			<div class="col-lg-2"></div>

			</div>

		</div>
		</div>

    <script src="js1/jquery.min.js"></script>
    <script src="js1/popper.js"></script>
    <script src="js1/bootstrap.min.js"></script>
	<script src="js1/main.js"></script>
	<script>
		
		</script>
  </body>
</html>