<?php
session_start();
$id2=$_SESSION['id'];
$serviceName=$_GET['serviceName'];
$date1=$_GET['date'];
$id=$_GET['id'];


$serviceBy=$_GET['serviceBy'];
$servername = "localhost";
$username = "username";
$password = "qwerty";
$dbname = "fyp";
        
        // Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $INSERT1="DELETE FROM appliedusers WHERE `id`='$id' AND `serviceBy`='$serviceBy' AND `joinedBy`='$id2'";   // $select * from `appliedusers` where `joinedBy`=$id && ``; -->        
    $result = $conn->query($INSERT1);
	if (mysqli_num_rows($result)==0) { header('location:news_feed.php');}
	else{"koni chali query ";$result = $conn -> query($INSERT1) or trigger_error($conn -> error." ".$INSERT1);
	header("refresh:3,url=news_feed.php?");
	}
    
?>