<?php
session_start();
$id2=$_SESSION['id'];?>
<!doctype html>
<html lang="en">
  <head>
    <title>Profile
    </title>
    <style>
		
			<!-- zoom effect on image -->
		
    .frame {
      height: 200px;
      width: 200px;
      overflow: hidden;
    }
    .zoomout img {
      height: 300px;
      width: 300px;
	  border-radius:50%;
      -webkit-transition: all 2s ease;
      -moz-transition: all 2s ease;
      -ms-transition: all 2s ease;
        transition: all 2s ease;
    }
    .zoomout img:hover {
      width: 200px;
      height: 200px;
    }



    </style>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Colorlib Templates">
    <meta name="author" content="Colorlib">
    <meta name="keywords" content="Colorlib Templates">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Title Page-->
    <!-- Icons font CSS-->
    <link href="../vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="../vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="../vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="../vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="../css/main.css" rel="stylesheet">
    <link href="../images/prologo.png" rel="icon" type="image/x-icon" />

    <!-- for bootstrap toogle-->

    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

	<script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-show-password/1.0.3/bootstrap-show-password.min.js"></script>





    
  </head>
  <body>
        
      <div class="page-wrapper bg-black font-robo">
            <div class="wrapper wrapper--w960">
                <br><br>
				
                <div class="card card-2" style="text-align:center;">
                    
                    <div class="card-body" style="text-align:center;">
                    <?php $servername = "localhost";
          $username = "username";
            $password = "qwerty";
         $dbname = "fyp";
        
        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
       
        $sql = "SELECT pic,password,level,name,email,address,phone,skills FROM `registration` where `email` = '$id2'";
        $result = $conn->query($sql);
        
        
        
        
        while($row = $result->fetch_assoc()) {
            $path=$row['pic'];
            
            $Password=$row['password'];
            $level=$row["level"];
            $Name=$row['name'];
            
            $email=$row['email'];
            
            $address=$row['address'];
            

           
            $phone=$row['phone'];
          

            $Skill=$row['skills'];
            
            
            }
            
        
        
        ?>
         
                        
                        <h4 class="title" style="display: inline;"><h3 style="display: inline;text-align: center;">Profile </h3> <br><strong class="" style="display: inline;"><br><?php echo "Welcome ";echo $Name;  ?></strong><br><br>
                        </h4>
						
                        <form action="registration.php" name="myForm" method="POST">
						<div class="row">
                        <div class="col-lg-3"></div>
                <div class="col-lg-6" style="text-align:center;">
                
                        <div class="row row-space">
                            
                                <div class="col-2">
                                    <div class="input-group">
                                            <input name="name" id=""class="input--style-2"  type="text" placeholder="<?php echo $Name;?>" name="name" required autofocus>
                                     </div>
                                </div>
								 <div class="col-2">
								
                                        <input class="input--style-2" style=" display: inline;" data-toggle="password" type="password" id="password"   pattern=".{6,}" title="Six or more characters" placeholder="****" value="<?php echo $Password;?>" name="password" required>
                                
                                </div>
								
								</div>
								
								
                               
                            
                            <div class="row row-space">
                            <div class="col-2">
                                    <div class="input-group">
                                            <input name="level" id="level"class="input--style-2"  type="text" placeholder="<?php echo $level;?>" name="level" required autofocus>
                                     </div>
                                </div>
                              <div class="col-2">
                              <div class="input-group">
                                            <input name="skills" id="skills"class="input--style-2"  type="text" placeholder="<?php echo $Skill;?>" name="skills" required autofocus>
                                     </div>

                              </div>

                                
                            </div>
                            <div class="input-group">
                                    <input name="address"class="input--style-2" type="text" size="50" placeholder="<?php echo $address;?>" required>
                            </div>
   
                            <div class="input-group">
                                <input name="email" class="input--style-2" type="email" size="50" pattern="[A-Za-z,@,.].{6,}" title="must have @" placeholder="<?php echo $email;?>" required>
                        </div>
                        <div class="input-group">
                            <input name="phone" class="input--style-2" type="text" size="50" placeholder="<?php echo $phone;?>" min="0"pattern="[0-9]{11}" title="Phone number of 11 digits"  title="Phone number" required>
                    </div>
                            <div class="p-t-30">
                                
                                <input style="color:whitesmoke;" class="btn btn-danger" type="submit" value="Update Changes">
                               <br>
                               <br>
                               <br>
                               <br> 
							   <h1> asdsafasfas</h1>
                            </div>
                            </div>
							</div>
                        </form>
                   
                    <!-- we can add here -->
                      <div class="row"><div class="col-lg-4"><h1>Hamza Pangy de rha  </h1></div>
                        <div class="col-lg-4">
                          <?php 
                          
		
                         
                          $sql = "SELECT name,regType,pic,skills,email FROM registration WHERE name='$id2'";
                              $result = $conn->query($sql);
                              if ($result->num_rows > 0) {
                                  while($row = $result->fetch_assoc()) {
                              
                              $path=$row['pic'];
                              echo "<div class='row'><div class='col-lg-2'></div>";
                              $redirectName=$row['name'];
                                    echo "<a href='profile_view.php?id=$redirectName'><img src='images/$path' style='border-radius: 50%; ' height='100px'/></a>";
                                    echo "<div class='card-body'>";
                                    echo "<h5 class='card-title'>";
                                    $serviceName=$row['email'];
                              echo "<a href='profile_view.php?id=$redirectName'>";
                                    echo $row['name'];
                              echo "</a>";
                                    echo "</h5>";
                                    echo  $row['regType'] ;
                              echo "<br>";
                              echo "Profession Type : ".$row['skills'];
                                    echo "</p>";
                              $SELECT4 = "SELECT friend FROM `friend` where `friend`='$serviceName' && `name`='$id2' ";   //to check pehly s tu dost nhe
                              $result4 = $conn->query($SELECT4);
                                    if ($result4->num_rows > 0){
                                    while($row = $result4->fetch_assoc()) {
                                    $name=$row['friend'];
                                    }
                                    if ($name==$serviceName){  
                              echo "<form action='remove_friend.php?friend=$serviceName' method='POST'>";
                                    echo "<button type='submit' class='btn btn-success'  data-toggle='modal' data-target='#exampleModalCenter'>";
                              echo "Remove Friend";
                              echo "</button></form>";
                                    }	  
                              }
                              else
                              {
                              echo "<form action='add_friend.php?friend=$serviceName' method='POST'>";
                              echo "<button type='submit' class='btn btn-danger' style='color:white;' data-toggle='modal' data-target='#exampleModalCenter'>";
                                    echo "Add as Friend";
                              echo "</button></form>";
                              }
                              
                                    echo "</div>";
                              echo "</div>";
                                    
                            
                                      }
                          }
                              else {
                                  echo " No Friends :( !";
                              }
                          ?>
                        </div>
                      </div>
                      </div>
                  <!-- is s oper oper kr bsdk -->
                </div>
                <br><br>
            </div>
        </div>
    
    <!-- Optiona
    l JavaScript -->
    <!-- Jquery JS-->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="../vendor/select2/select2.min.js"></script>
    <script src="../vendor/datepicker/moment.min.js"></script>
    <script src="../vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="../js/global.js"></script>
  </body>
</html>
<?php
if (!empty($id1)){
    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "qwerty";
    $dbname = "fyp";
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    if (mysqli_connect_error()) {
     die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    } else {

      //email check
        $SELECT = "SELECT email from registration where email = '$id1'";
        $result = $conn->query($SELECT);
        
      
      if ($result->num_rows > 0)
     {
         $SELECT = "DELETE email from registration where email = '$id1'";
        $result = $conn->query($SELECT);
      header("location:update_failed.html? name1=$id1");
     }
     else
     {
        mysqli_query($conn, $INSERT);
        header("refresh:3,url=home.php?id1=$email");
        //header("location:home.html");
     }
     $conn->close();
    }
}
?>