# ConVet

run pip install requirement.txt
run ./run.bat
