<?php
session_start();
$id=$_SESSION['id'];        // the one jiska friend hoga
$id2=$_GET['friend']; 
    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "qwerty";
    $dbname = "fyp";
    //create connection
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    if (mysqli_connect_error()) {
     die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    } else {

      $SELECT = "SELECT friend FROM `friend` where `friend`='$id2' && `name`='$id' ";   //to check pehly s tu dost nhe
      $result = $conn->query($SELECT);
      if (!$result) {
        trigger_error('Invalid query: ' . $conn->error);
    }
      if ($result->num_rows > 0){
      while($row = $result->fetch_assoc()) {
        $name=$row['friend'];
      }
      if ($name==$id2){
        
        header("location:news_Feed.php?id=$id");
        
      }
      }else{
        $SELECT1 = "INSERT INTO `friend`(`name`, `friend`) VALUES ('$id','$id2')";
        $result1 = $conn->query($SELECT1);
		?>
		<html>
		<body onload="myFunction()">
		<script>
		function myFunction() {
		alert("Added as Friend");
		}
		</script>
		</body></html>
		<?php
        header("refresh:0,url=news_Feed.php?id=$id");
      }
$conn->close();
    }
	?>
	